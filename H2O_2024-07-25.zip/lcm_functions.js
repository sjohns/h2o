/**
 * Utility functions for performing SKU-related calculations,
 * including calculating the Greatest Common Divisor (GCD),
 * the Least Common Multiple (LCM), and various SKU-specific fields.
 * 
 * Overview:
 * The Least Common Multiple (LCM) of two integers is the smallest positive integer
 * that is divisible by both numbers. For example, the LCM of 6 and 8 is 24 because
 * 24 is the smallest number that both 6 and 8 divide into without leaving a remainder.
 * The LCM is useful in various scenarios, such as finding common denominators in fractions,
 * scheduling recurring events, and synchronizing cycles. In this context, we use LCM to 
 * harmonize different SKU bundle quantities for logistics and planning.
 * 
 * Data Source:
 * The data used for these calculations is sourced from Eagle Charts.
 * 
 * Functions:
 * - gcd(a, b): Computes the greatest common divisor of two numbers a and b.
 * - lcm(a, b): Computes the least common multiple of two numbers a and b.
 * - calculateLCMOfArray(numbers): Computes the LCM of an array of numbers.
 * - calculateBundlesPerTruckload(SKUs): Calculates `calculatedBundlesPerTruckload` for each bundle in the SKUs object.
 * - calculateLCMFromBundles(SKUs): Extracts `calculatedBundlesPerTruckload` from bundles and computes their LCM.
 * - calculateAdditionalFields(SKUs, lcmValue): Calculates additional fields for each SKU based on the LCM value.
 * 
 * Example Usage:
 * const SKUs = {
 *     sku1: {
 *         skuId: "sku1",
 *         skuActive: "Y",
 *         sku: "12\" DR14 PVC PIPE C-900 - GASKET",
 *         size: "12\"",
 *         skuPopularityScore: 10,
 *         bundles: {
 *             bundleId_26: {
 *                 bundleId: "bundleId_26",
 *                 bundleActive: "Y",
 *                 eagleSticksPerBundle: 6,
 *                 eagleSticksPerTruckload: 98,
 *                 eaglePercentLoadPerLift: 7.1,
 *                 productTypeId: "productTypeId_1",
 *                 skuId: "sku1"
 *             }
 *         },
 *         productTypeId: "productTypeId_1"
 *     },
 *     // Add more SKUs as needed
 * };
 * 
 * // Step 1: Calculate `calculatedBundlesPerTruckload` for each bundle
 * calculateBundlesPerTruckload(SKUs);
 * 
 * // Step 2: Calculate LCM of `calculatedBundlesPerTruckload` values
 * const lcmValue = calculateLCMFromBundles(SKUs);
 * console.log('LCM of calculatedBundlesPerTruckload:', lcmValue);
 * 
 * // Step 3: Calculate additional fields based on LCM value
 * calculateAdditionalFields(SKUs, lcmValue);
 * console.log('Updated SKUs with additional fields:', SKUs);
 * 
 * Date: 2024-06-26
 * Author: Stephen Johns
 */

/**
 * Computes the greatest common divisor (GCD) of two numbers using the Euclidean algorithm.
 * The GCD is the largest positive integer that divides both numbers without a remainder.
 * 
 * @param {number} a - The first number.
 * @param {number} b - The second number.
 * @returns {number} - The greatest common divisor of a and b.
 */
function gcd(a, b) {
    while (b) {
        [a, b] = [b, a % b];
    }
    return a;
}

/**
 * Computes the least common multiple (LCM) of two numbers using their GCD.
 * The LCM is the smallest positive integer that is divisible by both numbers.
 * 
 * @param {number} a - The first number.
 * @param {number} b - The second number.
 * @returns {number} - The least common multiple of a and b.
 */
function lcm(a, b) {
    return (a * b) / gcd(a, b);
}

/**
 * Computes the LCM of an array of numbers.
 * This function reduces the array by iteratively computing the LCM of the accumulated result and the next number.
 * 
 * @param {number[]} numbers - An array of numbers.
 * @returns {number} - The LCM of the numbers in the array.
 */
function calculateLCMOfArray(numbers) {
    return numbers.reduce((acc, num) => lcm(acc, num), 1);
}

/**
 * Calculates `calculatedBundlesPerTruckload` for each bundle in the SKUs object.
 * This value is derived by rounding 100 divided by `eaglePercentLoadPerLift`.
 * 
 * @param {Object} SKUs - The SKUs object containing all SKUs and their bundles.
 */
function calculateBundlesPerTruckload(SKUs) {
    Object.values(SKUs).forEach(sku => {
        Object.values(sku.bundles).forEach(bundle => {
            bundle.calculatedBundlesPerTruckload = Math.round(100 / bundle.eaglePercentLoadPerLift);
        });
    });
}

/**
 * Extracts `calculatedBundlesPerTruckload` values from each bundle and computes their LCM.
 * 
 * @param {Object} SKUs - The SKUs object containing all SKUs and their bundles.
 * @returns {number} - The LCM of the `calculatedBundlesPerTruckload` values.
 */
function calculateLCMFromBundles(SKUs) {
    const bundlesPerTruckloadValues = [];

    Object.values(SKUs).forEach(sku => {
        Object.values(sku.bundles).forEach(bundle => {
            bundlesPerTruckloadValues.push(bundle.calculatedBundlesPerTruckload);
        });
    });

    return calculateLCMOfArray(bundlesPerTruckloadValues);
}

/**
 * Calculates additional fields `calculatedBundleSize` and `calculatedSticksPerBundle` 
 * for each bundle in each SKU based on the provided LCM value.
 * 
 * @param {Object} SKUs - The SKUs object containing all SKUs and their bundles.
 * @param {number} lcmValue - The LCM value used for calculations.
 */
function calculateAdditionalFields(SKUs, lcmValue) {
    Object.values(SKUs).forEach(sku => {
        Object.values(sku.bundles).forEach(bundle => {
            // `calculatedBundleSize` is the ratio of the LCM value to the bundle's calculated bundles per truckload
            bundle.calculatedBundleSize = lcmValue / bundle.calculatedBundlesPerTruckload;
            // `calculatedSticksPerBundle` is the number of sticks per truckload divided by the calculated bundles per truckload, rounded to the nearest whole number
            bundle.calculatedSticksPerBundle = Math.round(bundle.eagleSticksPerTruckload / bundle.calculatedBundlesPerTruckload);
        });
    });
}

/* 
// Example Usage:
const SKUs = {
    "skuId_1": {
        "skuId": "skuId_1",
        "skuActive": "Y",
        "sku": "12\" DR14 PVC PIPE C-900 - GASKET",
        "size": "12\"",
        "skuPopularityScore": 10,
        "bundles": {
            "bundleId_26": {
                "bundleId": "bundleId_26",
                "bundleActive": "Y",
                "eagleSticksPerBundle": 105,
                "eagleSticksPerTruckload": 2520,
                "eaglePercentLoadPerLift": 4.2,
                "productTypeId": "productTypeId_1",
                "skuId": "skuId_1"
            }
        },
        "productTypeId": "productTypeId_1"
    },
    // More SKUs...
};

// Step 1: Calculate `calculatedBundlesPerTruckload` for each bundle
calculateBundlesPerTruckload(SKUs);

// Step 2: Calculate LCM of `calculatedBundlesPerTruckload` values
const lcmValue = calculateLCMFromBundles(SKUs);
console.log('LCM of calculatedBundlesPerTruckload:', lcmValue);

// Step 3: Calculate additional fields based on LCM value
calculateAdditionalFields(SKUs, lcmValue);
console.log('Updated SKUs with additional fields:', SKUs);

// Additional Testing:
console.log('GCD of 6 and 8:', gcd(6, 8));  // Output should be 2
console.log('LCM of 6 and 8:', lcm(6, 8));  // Output should be 24
console.log('LCM of array [6, 8, 12]:', calculateLCMOfArray([6, 8, 12]));  // Output should be 24

 */
