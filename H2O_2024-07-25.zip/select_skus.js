/**
 * Function Description:
 * selectSkus:
 * - This function dynamically creates a user interface for selecting active pipe SKUs.
 * - It creates a table displaying the SKUs and allows the user to select SKUs by clicking on them.
 * - The user can select a maximum of 5 pipe SKUs and then click the "Create Order" button to process the selected SKUs.
 * - The function also includes validation to ensure that at least one SKU is selected and no more than 5 SKUs are selected.
 * - Upon clicking "Create Order," the selected SKUs are logged to the console, and SKUs not selected are removed from the SKUs object.
 * 
 * Variables:
 * - selectSkusDiv: The 'selectSkus' div element from the DOM.
 * - contentDiv: A container for the SKU selection content.
 * - title: A title element for the SKU selection interface.
 * - table: A table element for displaying the SKUs.
 * - tableHeader: A header row for the table.
 * - headerText: An array of header text for the table.
 * - createOrderButton: A button element to create the order.
 * 
 * Steps Performed by selectSkus:
 * 
 * 1. Validation:
 *    - The function first checks if the provided SKUs object is valid. If not, it logs an error and returns.
 *    
 *      if (!skus || typeof skus !== 'object' || Object.keys(skus).length === 0) {
 *          console.error('Invalid skus object provided.');
 *          return;
 *      }
 * 
 * 2. Retrieve the 'selectSkus' div:
 *    - The function retrieves the 'selectSkus' div element from the DOM.
 *    
 *      const selectSkusDiv = document.getElementById('selectSkus');
 * 
 * 3. Create a container for the SKU selection content:
 *    - A contentDiv element is created and styled to hold the SKU selection interface.
 *    
 *      let contentDiv = document.createElement('div');
 *      contentDiv.style.display = 'flex';
 *      contentDiv.style.flexDirection = 'column';
 *      contentDiv.style.alignItems = 'center';
 * 
 * 4. Create a title for the SKU selection:
 *    - A title element is created and appended to the contentDiv.
 *    
 *      const title = document.createElement('h1');
 *      title.textContent = 'Select Pipe(s)';
 *      title.style.textAlign = 'center';
 *      contentDiv.appendChild(title);
 * 
 * 5. Create a table for SKU selection:
 *    - A table element is created with a header row and appended to the contentDiv.
 *    
 *      const table = document.createElement('table');
 *      table.border = '1';
 *      const tableHeader = document.createElement('tr');
 *      const headerText = ['Pipes'];
 * 
 * 6. Iterate over each active SKU:
 *    - The function iterates through each active SKU, creating rows and cells for each SKU.
 *    
 *      Object.values(skus).forEach(sku => {
 *          const skuDescription = sku.sku;
 * 
 *      - Add event listener to SKU description cell:
 *        - The cell changes background color and toggles a hidden checkbox when clicked.
 *        
 *          skuDescriptionCell.addEventListener('click', function () {
 *              const selectCheckbox = this.querySelector('input[type="checkbox"]');
 *              selectCheckbox.checked = !selectCheckbox.checked;
 *              if (selectCheckbox.checked) {
 *                  this.parentNode.style.backgroundColor = 'lightgreen';
 *              } else {
 *                  this.parentNode.style.backgroundColor = '';
 *              }
 *          });
 * 
 * 7. Create a "Create Order" button:
 *    - The button is created and appended to the contentDiv.
 *    
 *      const createOrderButton = document.createElement('button');
 *      createOrderButton.textContent = 'Create Order';
 *      contentDiv.appendChild(createOrderButton);
 * 
 * 8. Append the content div to the 'selectSkus' div:
 *    - The contentDiv is appended to the 'selectSkus' div.
 *    
 *      selectSkusDiv.appendChild(contentDiv);
 * 
 * 9. Add click event listener to "Create Order" button:
 *    - The event listener validates the selected SKUs and processes the order.
 *    
 *      createOrderButton.addEventListener('click', function () {
 *          let selectedSkus = Array.from(document.querySelectorAll('input[name=selectedsku]:checked')).map(checkbox => checkbox.value);
 *          let numberOfSkus = selectedSkus.length;
 *          // Check if at least one SKU is selected
 *          if (numberOfSkus === 0) {
 *              alert('Please select at least one pipe SKU before creating an order.');
 *          } else if (numberOfSkus > 5) {
 *              alert('Please select a maximum of 5 pipe SKUs before creating an order.');
 *          } else {
 *              // Filter out SKUs not in selectedSkus from SKUs object
 *              for (const skuId in skus) {
 *                  if (!selectedSkus.includes(skuId)) {
 *                      delete skus[skuId];
 *                  }
 *              }
 *              console.log('Filtered SKUs:', skus);
 *              
 *              if (numberOfSkus === 1) {
 *                  // If exactly one SKU is selected, directly call the functions for one SKU
 *                  const selectedSkuId = selectedSkus[0];
 *                  orderTable = new OrderTable(skus, [], {}); // Passing empty solution and branchAndBoundEngine as placeholders
 *                  orderTable.createOrderTableOneSku(selectedSkuId);
 *                  orderTable.createOrderTableDetailOneSku(selectedSkuId);
 *              } else {
 *                  // Calculate bundles and additional fields for multiple SKUs
 *                  calculateBundlesPerTruckload(skus);
 *                  const lcmValue = calculateLCMFromBundles(skus);
 *                  console.log('LCM of calculatedBundlesPerTruckload:', lcmValue);
 *
 *                  calculateAdditionalFields(skus, lcmValue);
 *                  console.log('Updated SKUs with additional fields:', skus);
 *
 *                  // Initialize ratios calculator and branch and bound engine
 *                  ratiosCalculator = new CalculateRatios(skus);
 *                  branchAndBoundEngine = new BranchAndBoundEngine(skus, lcmValue, ratiosCalculator);
 *                  console.log("LCM of calculatedBundlesPerTruckload values:", lcmValue);
 *
 *                  // Get the best solution
 *                  solution = branchAndBoundEngine.bestSolution();
 *                  console.log("Optimal Solution:", solution);
 *
 *                  // Call the existing functions for multiple SKUs
 *                  orderTable = new OrderTable(skus, solution, branchAndBoundEngine);
 *                  orderTable.createOrderTable();
 *                  orderTable.createPackingSlip();
 *
 *                  // Update button states
 *                  branchAndBoundEngine.updateButtonStates();
 *              }
 *          }
 *      });
 */

function selectSkus(skus) {
    // Check if skus object is valid
    if (!skus || typeof skus !== 'object' || Object.keys(skus).length === 0) {
        console.error('Invalid skus object provided.');
        return;
    }

    // Get the 'selectskus' div element
    const selectSkusDiv = document.getElementById('selectSkus');
    if (!selectSkusDiv) {
        console.error('Element with id "selectSkus" not found.');
        return;
    }

    // Create a container for the sku selection content
    let contentDiv = document.createElement('div');
    contentDiv.style.display = 'flex';
    contentDiv.style.flexDirection = 'column';
    contentDiv.style.alignItems = 'center';

    // Create a title for the sku selection
    const title = document.createElement('h1');
    title.textContent = 'Select Pipe(s)';
    title.style.textAlign = 'center';
    contentDiv.appendChild(title);

    // Create a table for sku selection
    const table = document.createElement('table');
    table.border = '1';

    // Create a table header
    const tableHeader = document.createElement('tr');
    const headerText = ['Pipes'];

    // Add headers to the table header
    headerText.forEach(text => {
        const header = document.createElement('th');
        header.textContent = text;
        tableHeader.appendChild(header);
    });

    // Append the table header to the table
    table.appendChild(tableHeader);

    // Iterate over each active sku
    Object.values(skus).forEach(sku => {
        const skuDescription = sku.sku;

        // Create a row for sku details
        const row = document.createElement('tr');

        // Create cells for each property
        const skuIdCell = document.createElement('td');
        skuIdCell.style.display = 'none'; // Hide the skuId cell
        skuIdCell.textContent = sku.skuId;

        const skuDescriptionCell = document.createElement('td');
        skuDescriptionCell.textContent = skuDescription;
        skuDescriptionCell.style.cursor = 'pointer'; // Change cursor to pointer
        skuDescriptionCell.addEventListener('click', function () {
            const selectCheckbox = this.querySelector('input[type="checkbox"]');
            selectCheckbox.checked = !selectCheckbox.checked; // Toggle checkbox
            if (selectCheckbox.checked) {
                this.parentNode.style.backgroundColor = 'lightgreen'; // Highlight row
            } else {
                this.parentNode.style.backgroundColor = ''; // Reset to default
            }
        });

        // Append cells to the row
        row.appendChild(skuIdCell);
        row.appendChild(skuDescriptionCell);

        // Create a hidden checkbox
        const selectCheckbox = document.createElement('input');
        selectCheckbox.type = 'checkbox';
        selectCheckbox.name = 'selectedsku'; // Fixed name attribute
        selectCheckbox.value = sku.skuId; // Assuming skuId is the unique identifier
        selectCheckbox.style.display = 'none'; // Hide the checkbox
        skuDescriptionCell.appendChild(selectCheckbox);

        // Append the row to the table
        table.appendChild(row);
    });

    // Append the table to the content div
    contentDiv.appendChild(table);

    // Create a "Create Order" button
    const createOrderButton = document.createElement('button');
    createOrderButton.textContent = 'Create Order';
    contentDiv.appendChild(createOrderButton);

    // Append the content div to the 'selectskus' div
    selectSkusDiv.appendChild(contentDiv);

    // Add a click event listener to the "Create Order" button
    createOrderButton.addEventListener('click', function () {
        // Get selected skus
        let selectedSkus = Array.from(document.querySelectorAll('input[name=selectedsku]:checked')).map(checkbox => checkbox.value);
        let numberOfSkus = selectedSkus.length;
        // Check if at least one sku is selected
        if (numberOfSkus === 0) {
            alert('Please select at least one pipe sku before creating an order.');
        } else if (numberOfSkus > 5) {
            alert('Please select a maximum of 5 pipe skus before creating an order.');
        } else {
            // Filter out skus not in selectedSkus from skus object
            for (const skuId in skus) {
                if (!selectedSkus.includes(skuId)) {
                    delete skus[skuId];
                }
            }
            console.log('Filtered SKUs:', skus);

            if (numberOfSkus === 1) {
                // If exactly one SKU is selected, directly call the functions for one SKU
                const selectedSkuId = selectedSkus[0];
                orderTable = new OrderTable(skus, [], {}); // Passing empty solution and branchAndBoundEngine as placeholders
                orderTable.createOrderTableOneSku(selectedSkuId);
                orderTable.createOrderTableDetailOneSku(selectedSkuId);
            } else {
                // Calculate bundles and additional fields for multiple SKUs
                calculateBundlesPerTruckload(skus);
                const lcmValue = calculateLCMFromBundles(skus);
                console.log('LCM of calculatedBundlesPerTruckload:', lcmValue);

                calculateAdditionalFields(skus, lcmValue);
                console.log('Updated SKUs with additional fields:', skus);

                // Initialize ratios calculator and branch and bound engine
                ratiosCalculator = new CalculateRatios(skus);
                branchAndBoundEngine = new BranchAndBoundEngine(skus, lcmValue, ratiosCalculator);
                console.log("LCM of calculatedBundlesPerTruckload values:", lcmValue);

                // Get the best solution
                solution = branchAndBoundEngine.bestSolution();
                console.log("Optimal Solution:", solution);

                // Call the existing functions for multiple SKUs
                orderTable = new OrderTable(skus, solution, branchAndBoundEngine);
                orderTable.createOrderTable();
                orderTable.createPackingSlip();

                // Update button states
                branchAndBoundEngine.updateButtonStates();
            }
        }
    });
}

