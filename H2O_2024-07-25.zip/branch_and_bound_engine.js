/**
 * BranchAndBoundEngine class:
 * - This class implements a Branch and Bound algorithm to find optimal solutions for SKUs within given constraints.
 * 
 * Overview:
 * The purpose of this class is to determine the optimal combination of SKU bundles that can be loaded onto a truck
 * without exceeding its capacity, while also considering the popularity score differences of the SKUs.
 * This is done by employing the Branch and Bound algorithm, which efficiently explores the possible combinations of SKU bundles.
 * 
 * Description:
 * This class handles the optimization problem where multiple SKUs (Stock Keeping Units) need to be packed into a truck.
 * Each SKU has a certain number of bundles and a specific bundle size. The goal is to maximize the truck load without exceeding its capacity
 * and to minimize the popularity score differences between the chosen SKUs. The class uses the Branch and Bound algorithm to systematically
 * explore possible combinations and prune non-promising branches to find the best solution efficiently.
 *
 * Variables:
 * - SKUs: The SKUs containing SKU information.
 * - lcmValue: The least common multiple value used for truck size calculations.
 * - fullTruckSize: The full truck size based on the lcmValue.
 * - MOD_SIZE: The modulus size used for divisible unit checks.
 * - minFractionMultipleSkus: Minimum fraction of multiple SKUs.
 * - maxFractionMultipleSkus: Maximum fraction of multiple SKUs.
 * - bundleConstraints: Constraints for each SKU regarding the number of bundles.
 * - bundleConstraintsInitial: Initial constraints for each SKU.
 * - bundleConstraintsLast: Last constraints for each SKU.
 * - truckSizeConstraints: Constraints for the truck size.
 * - ratiosCalculator: Calculator for SKU popularity score differences.
 * - bundles: The bundles within the SKUs.
 * - solutions: Array of possible solutions.
 * - lastSolutions: Array of the last possible solutions.
 * - memo: Set for memoization to avoid redundant calculations.
 *
 * Methods:
 * 
 * 1. Constructor:
 *    - Initializes the `BranchAndBoundEngine` class with SKUs and lcmValue.
 *    - Calls `_initializeConstraints` to set default properties for constraints.
 *
 * 2. _initializeConstraints:
 *    - Initializes the constraints for truck size and bundles.
 *    - Sets initial, current, and last constraints for bundles.
 *
 * 3. _calculateTruckSkuConstraints:
 *    - Calculates constraints for truck size based on SKU bundles.
 *
 * 4. _calculateBundlesAndBundleConstraints:
 *    - Initializes bundle constraints and stores the initial and last constraints.
 *
 * 5. _calculateNumberOfBundlesPerSkuConstraints:
 *    - Calculates the constraints on the number of bundles per SKU.
 *
 * 6. _findAllSolutions:
 *    - Finds all possible solutions by recursively finding combinations of bundles.
 *
 * 7. _findCombinations:
 *    - Recursively finds combinations of bundles that fit within the constraints.
 *
 * 8. _isValidSolution:
 *    - Checks if a solution is valid based on truck size and bundle constraints.
 *
 * 9. bestSolution:
 *    - Finds the best solution based on truck size and SKU popularity score differences.
 *
 * 10. _checkNumberOfBundlesPerSku:
 *     - Checks the number of bundles per SKU against the constraints.
 *
 * 11. _countBundlesPerSku:
 *     - Counts the number of bundles for each SKU in a solution.
 *
 * 12. _checkBundleConstraints:
 *     - Checks if the number of bundles for a bundleId is within the constraints.
 *
 * 13. _findBundleById:
 *     - Finds a bundle by its ID within the SKUs.
 *
 * 14. _findSkuByBundleId:
 *     - Finds a SKU by a bundle ID within the SKUs.
 *
 * 15. _deepClone:
 *     - Creates a deep clone of the provided object.
 *
 * 16. _handleError:
 *     - Handles errors by logging them to the console.
 *
 * 17. updateConstraints:
 *     - Updates the constraints for a given SKU based on the action performed.
 *
 * 18. updateButtonStates:
 *     - Updates the states of the buttons based on the current bundle constraints.
 *
 * 19. updateAll:
 *     - Updates all relevant parts of the system based on the action performed.
 *
 * 20. _findOptimumSolution:
 *     - Finds the optimal solution based on truck size and popularity score differences.
 *
 * Date: 2024-06-26
 * Author: Stephen Johns
 */

class BranchAndBoundEngine {
    constructor(SKUs, lcmValue, ratiosCalculator) {
        this.SKUs = SKUs;
        this.lcmValue = lcmValue;
        this.fullTruckSize = lcmValue;
        this.MOD_SIZE = 6;
        this.minFractionMultipleSkus = 0.95;
        this.maxFractionMultipleSkus = 1.00;
        this.bundleConstraints = {};
        this.bundleConstraintsInitial = {};
        this.bundleConstraintsLast = {};
        this.numberOfBundlesPerSkuConstraints = {};
        this.numberOfBundlesPerSkuConstraintsLast = {};
        this.numberOfBundlesPerSkuConstraintsInitial = {};
        this.truckSizeConstraints = {};
        this.ratiosCalculator = ratiosCalculator;
        this.bundles = {};
        this.solutions = [];
        this.lastSolutions = [];
        this.memo = new Set(); // Initialize the memoization cache
        this._initializeConstraints();
    }
    
    _initializeConstraints() {
        this._calculateTruckSkuConstraints();
        console.log('Truck size constraints:', this.truckSizeConstraints);
        
        this._calculateBundlesAndBundleConstraints();
        console.log('Bundle constraints:', this.bundleConstraints);

        this._calculateNumberOfBundlesPerSkuConstraints();
        console.log('Number of bundles per SKU constraints:', this.numberOfBundlesPerSkuConstraints);
    }

    _calculateTruckSkuConstraints() {
        const onlyOneBundlePerSKU = Object.values(this.SKUs).every(sku => Object.keys(sku.bundles).length === 1);

        if (onlyOneBundlePerSKU) {
            const allDivisibleByModSize = Object.values(this.SKUs).every(sku => {
                return Object.values(sku.bundles).every(bundle => {
                    return bundle.bundlesPerTruckload % this.MOD_SIZE === 0;
                });
            });

            if (allDivisibleByModSize) {
                this.truckSizeConstraints = { minTruckSize: this.fullTruckSize, maxTruckSize: this.fullTruckSize };
            } else {
                const minTruckSize = Math.round(this.fullTruckSize * this.minFractionMultipleSkus);
                const maxTruckSize = Math.round(this.fullTruckSize * this.maxFractionMultipleSkus);
                this.truckSizeConstraints = { minTruckSize, maxTruckSize };
            }
        } else {
            const minTruckSize = Math.round(this.fullTruckSize * this.minFractionMultipleSkus);
            const maxTruckSize = Math.round(this.fullTruckSize * this.maxFractionMultipleSkus);
            this.truckSizeConstraints = { minTruckSize, maxTruckSize };
        }
    }

    _calculateBundlesAndBundleConstraints() {
        try {
            Object.values(this.SKUs).forEach(sku => {
                Object.values(sku.bundles).forEach(bundle => {
                    // Initialize the bundles object
                    this.bundles[bundle.bundleId] = bundle;
                    this.bundleConstraints[bundle.bundleId] = {
                        minNumberOfBundles: 0,
                        maxNumberOfBundles: bundle.calculatedBundlesPerTruckload
                    };
                });
            });
            this.bundleConstraintsInitial = this._deepClone(this.bundleConstraints);
            this.bundleConstraintsLast = this._deepClone(this.bundleConstraints);
        } catch (error) {
            this._handleError('Error calculating bundle constraints', error);
        }
    }

    _calculateNumberOfBundlesPerSkuConstraints() {
        try {
            Object.values(this.SKUs).forEach(sku => {
                if (!sku || typeof sku.bundles !== 'object') {
                    return; // skip this SKU
                }

                const maxNumberOfBundles = Object.values(sku.bundles).reduce((maxBundles, bundle) => {
                    if (typeof bundle.calculatedBundlesPerTruckload !== 'number') {
                        return maxBundles; // ignore this bundle and continue
                    }
                    return Math.max(maxBundles, bundle.calculatedBundlesPerTruckload);
                }, 0);

                this.numberOfBundlesPerSkuConstraints[sku.skuId] = {
                    minNumberOfBundles: 1,
                    maxNumberOfBundles: maxNumberOfBundles
                };
            });

            this.numberOfBundlesPerSkuConstraintsInitial = this._deepClone(this.numberOfBundlesPerSkuConstraints);
            this.numberOfBundlesPerSkuConstraintsLast = this._deepClone(this.numberOfBundlesPerSkuConstraints);
        } catch (error) {
            this._handleError('Error calculating number of bundles per SKU constraints', error);
        }
    }

    _findAllSolutions() {
        try {
            this.solutions = [];
            const allBundles = Object.keys(this.bundleConstraints);

            // Start finding combinations with all collected bundles
            this._findCombinations(allBundles, [], 0);

            if (this.solutions.length < 1) {
                alert('No possible solutions for last modification. The last modification has been reversed.');
                console.warn('No possible solutions for last modification. The last modification has been reversed.');
                this.solutions = this.lastSolutions;
                this.numberOfBundlesPerSkuConstraints = this._deepClone(this.numberOfBundlesPerSkuConstraintsLast);
            }

            console.log("All Solutions:", this.solutions);
            return this.solutions;
        } catch (error) {
            this._handleError('Error finding all solutions', error);
        }
    }

    _findCombinations(bundles, solution, totalSize) {
        if (bundles.length === 0) {
            if (this._isValidSolution(solution, totalSize)) {
                this.solutions.push([...solution]);
            }
            return;
        }

        const [bundleId, ...remainingBundles] = bundles;
        const constraints = this.bundleConstraints[bundleId];
        const bundleInfo = this.bundles[bundleId];

        for (let numberOfBundles = constraints.minNumberOfBundles; numberOfBundles <= constraints.maxNumberOfBundles; numberOfBundles++) {
            const newSize = totalSize + numberOfBundles * bundleInfo.calculatedBundleSize;
            if (newSize > this.truckSizeConstraints.maxTruckSize) break;
            solution.push({ bundleId, numberOfBundles });
            this._findCombinations(remainingBundles, solution, newSize);
            solution.pop();
        }
    }

    _isValidSolution(solution, totalSize) {
        return this._checkNumberOfBundlesPerSku(solution) &&
            totalSize >= this.truckSizeConstraints.minTruckSize &&
            totalSize <= this.truckSizeConstraints.maxTruckSize;
    }

    bestSolution() {
        console.log('truckSizeConstraints:', this.truckSizeConstraints);
        this._findAllSolutions();
        const optimalSolution = this._findOptimumSolution();
        console.log('Optimal solution found:', optimalSolution);
        return optimalSolution;
    }

    _checkNumberOfBundlesPerSku(solution) {
        try {
            const skuBundlesCount = this._countBundlesPerSku(solution);

            for (const [skuId, count] of Object.entries(skuBundlesCount)) {
                const constraints = this.numberOfBundlesPerSkuConstraints[skuId];
                if (count < constraints.minNumberOfBundles || count > constraints.maxNumberOfBundles) {
                    return false;
                }
            }

            return true;
        } catch (error) {
            this._handleError('Error checking number of bundles per SKU', error);
        }
    }

    _countBundlesPerSku(solution) {
        const skuBundlesCount = {};
        solution.forEach(item => {
            const sku = this._findSkuByBundleId(item.bundleId);
            if (!skuBundlesCount[sku.skuId]) {
                skuBundlesCount[sku.skuId] = 0;
            }
            skuBundlesCount[sku.skuId] += item.numberOfBundles;

            this._checkBundleConstraints(item);
        });
        return skuBundlesCount;
    }

    _checkBundleConstraints(item) {
        const bundleConstraints = this.bundleConstraints[item.bundleId];
        if (item.numberOfBundles < bundleConstraints.minNumberOfBundles || item.numberOfBundles > bundleConstraints.maxNumberOfBundles) {
            throw new Error(`Number of bundles for bundleId ${item.bundleId} is out of bounds.`);
        }
    }

    _findBundleById(bundleId) {
        console.log(`findBundleById ${bundleId}`);
        for (const sku of Object.values(this.SKUs)) {
            if (sku.bundles.hasOwnProperty(bundleId)) {
                return sku.bundles[bundleId];
            }
        }
        throw new Error(`Bundle with ID ${bundleId} not found`);
    }

    _findSkuByBundleId(bundleId) {
        for (const sku of Object.values(this.SKUs)) {
            if (sku.bundles.hasOwnProperty(bundleId)) {
                return sku;
            }
        }
        throw new Error(`SKU with bundleId ${bundleId} not found`);
    }

    _deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    }

    _handleError(message, error) {
        console.error(message, error);
        throw new Error(message);
    }

    updateConstraints(skuId, action, numberOfBundles) {
        console.log(`skuId ${skuId}  action ${action} numberOfBundles ${numberOfBundles}`);
        
        // Generate the IDs for the increase and decrease buttons based on SKU
        const orderTableDataIncreaseAmountId = '#orderTableDataIncreaseAmountId' + skuId;
        const orderTableDataDecreaseAmountId = '#orderTableDataDecreaseAmountId' + skuId;

        const minNumberOfBundlesInitial = this.numberOfBundlesPerSkuConstraintsInitial[skuId].minNumberOfBundles;
        const maxNumberOfBundlesInitial = this.numberOfBundlesPerSkuConstraintsInitial[skuId].maxNumberOfBundles;
        
        console.log(`Initial Bundle Sizes: skuId ${skuId}, Min ${minNumberOfBundlesInitial},  Max ${maxNumberOfBundlesInitial}`);

        let minNumberOfBundles = this.numberOfBundlesPerSkuConstraints[skuId].minNumberOfBundles;
        let maxNumberOfBundles = this.numberOfBundlesPerSkuConstraints[skuId].maxNumberOfBundles;
        
        console.log(`Current Bundle Sizes: skuId ${skuId}, Min ${minNumberOfBundles},  Max ${maxNumberOfBundles}`);

        switch (action) {
            case 'correctAmount':
                this.numberOfBundlesPerSkuConstraints[skuId].minNumberOfBundles = numberOfBundles;
                this.numberOfBundlesPerSkuConstraints[skuId].maxNumberOfBundles = numberOfBundles;
                break;
            case 'notCorrectAmount':
                this.numberOfBundlesPerSkuConstraints[skuId].minNumberOfBundles = this.numberOfBundlesPerSkuConstraintsInitial[skuId].minNumberOfBundles;
                this.numberOfBundlesPerSkuConstraints[skuId].maxNumberOfBundles = this.numberOfBundlesPerSkuConstraintsInitial[skuId].maxNumberOfBundles;
                break;
            case 'increase':
                if (numberOfBundles < maxNumberOfBundlesInitial) {
                    const newNumberOfBundles = Math.max(0, parseInt(numberOfBundles) + 1);
                    if (newNumberOfBundles >= maxNumberOfBundles) { 
                        this.numberOfBundlesPerSkuConstraints[skuId].maxNumberOfBundles = maxNumberOfBundlesInitial; 
                    }
                    this.numberOfBundlesPerSkuConstraints[skuId].minNumberOfBundles = newNumberOfBundles;
                }
                break;
            case 'decrease':          
                if (numberOfBundles > minNumberOfBundlesInitial) {
                    const newNumberOfBundles = Math.max(0, parseInt(numberOfBundles) - 1);
                    if (newNumberOfBundles <= minNumberOfBundles) { 
                        this.numberOfBundlesPerSkuConstraints[skuId].minNumberOfBundles = minNumberOfBundlesInitial; 
                    }
                    this.numberOfBundlesPerSkuConstraints[skuId].maxNumberOfBundles = newNumberOfBundles;                              
                }
                break;
            default:
                throw new Error(`Unknown action: ${action}`);
        }
        
        minNumberOfBundles = this.numberOfBundlesPerSkuConstraints[skuId].minNumberOfBundles;
        maxNumberOfBundles = this.numberOfBundlesPerSkuConstraints[skuId].maxNumberOfBundles;
        
        console.log(`After Bundle Sizes: skuId ${skuId}, Min ${minNumberOfBundles},  Max ${maxNumberOfBundles}`);                            
    }

    updateButtonStates() {
        Object.keys(this.SKUs).forEach(skuId => {
            const orderTableDataIncreaseAmountId = `#orderTableDataIncreaseAmountId${skuId}`;
            const orderTableDataDecreaseAmountId = `#orderTableDataDecreaseAmountId${skuId}`;
            const correctAmountCheckboxId = `#orderTableDataCorrectAmountId${skuId}`;

            $(orderTableDataIncreaseAmountId).prop('disabled', false);
            $(orderTableDataDecreaseAmountId).prop('disabled', false);
            $(correctAmountCheckboxId).prop('checked', false);

            const numberOfBundles = parseInt(document.querySelector(`#orderTableDataRowId${skuId}`).getAttribute('data-total-bundles'));

            const minNumberOfBundles = this.numberOfBundlesPerSkuConstraintsInitial[skuId].minNumberOfBundles;
            const maxNumberOfBundles = this.numberOfBundlesPerSkuConstraintsInitial[skuId].maxNumberOfBundles;

            if (numberOfBundles >= maxNumberOfBundles) {
                $(orderTableDataIncreaseAmountId).prop('disabled', true);
            }
            if (numberOfBundles <= minNumberOfBundles) {
                $(orderTableDataDecreaseAmountId).prop('disabled', true);
            }
        });
    }

    updateAll(skuId, action, bundles) {
        this.updateConstraints(skuId, action, bundles);
        this._findAllSolutions();
        const optimalSolution = this._findOptimumSolution();
        orderTable = new OrderTable(this.SKUs, optimalSolution, this);  // Assuming OrderTable is defined elsewhere
        this.updateButtonStates();
    }

    _findOptimumSolution() {
        let bestSolution = null;
        let bestTruckSize = -Infinity;
        let bestDifference = Infinity;

        this.solutions.forEach(solution => {
            // Calculate the total truck size for the solution
            let truckSize = solution.reduce((total, item) => {
                const bundle = this.bundles[item.bundleId];
                return total + (bundle.calculatedBundleSize * item.numberOfBundles);
            }, 0);

            // If the truck size is less than the current best, skip it
            if (truckSize < bestTruckSize) {
                return;
            }

            // Calculate the ratio difference for the solution
            let ratioDifference = this.ratiosCalculator.popularityScoreDifference(solution);

            // If the truck size is greater than the current best or the ratio difference is less than the current best difference
            if (truckSize > bestTruckSize || (truckSize === bestTruckSize && ratioDifference < bestDifference)) {
                bestTruckSize = truckSize;
                bestDifference = ratioDifference;
                bestSolution = [...solution];
            }
        });

        console.log("Best Truck Size:", bestTruckSize);
        console.log("Best Difference:", bestDifference);
        console.log("Best Solution:", bestSolution);
        return bestSolution;
    }
}

