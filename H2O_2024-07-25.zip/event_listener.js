/**
 * Function to clear existing content of an element and initialize SKU selection on DOM content loaded.
 * 
 * Description:
 * - This script provides a function to clear all child elements from a given DOM element.
 * - It also sets up an event listener that triggers once the DOM content is fully loaded.
 * - When the DOM is loaded, it processes packing data to extract SKUs and calls the `selectSkus` function to render the SKU selection interface.
 * - If the `selectSkus` div is empty after the initial rendering, it re-runs the `selectSkus` function and logs the selected SKUs.
 * 
 * @param {HTMLElement} element - The DOM element to be cleared of its child elements.
 */

/**
 * Explanation:
 * 
 * - Function `clearElement`:
 *   - Clears all child elements from the specified DOM element.
 *   - Uses a `while` loop to continuously remove the first child until there are no more children left.
 * 
 * - Event listener for `DOMContentLoaded`:
 *   - This event fires when the initial HTML document has been completely loaded and parsed.
 *   - Inside this event listener:
 *     - The `processPackingData` function is called with `packingData` to extract SKUs.
 *     - The `selectSkus` function is called with the processed SKUs to render the SKU selection interface.
 *     - The script checks if the `selectSkus` div is empty.
 *     - If it is empty, the `selectSkus` function is called again, and the selected SKUs are logged to the console.
 *     - Optionally, an instance of `BranchAndBound` could be initialized with the selected SKUs and product types (commented out in the provided code).
 */

// Function to clear existing content of an element
/**
 * Clears all child elements from the specified DOM element.
 * @param {HTMLElement} element - The DOM element to be cleared of its child elements.
 */
function clearElement(element) {
    // Continuously remove the first child element until there are no more child elements
    while (element.firstChild) {
        element.removeChild(element.firstChild);
    }
}

// Event listener for when the DOM content has been fully loaded
document.addEventListener('DOMContentLoaded', function () {
    // Process packing data to extract SKUs
    const SKUs = processPackingData(packingData);

    // Log the processed SKUs to the console
    console.log(SKUs);

    // Call the selectSkus function with the processed SKUs to render the SKU selection interface
    selectSkus(SKUs);

    // Get the 'selectSkus' div element by its ID
    const selectSkusDiv = document.getElementById('selectSkus');

    // If the 'selectSkus' div is empty after the initial rendering
    if (selectSkusDiv.children.length === 0) {
        // Re-run the selectSkus function with the processed SKUs
        const selectedSkus = selectSkus(SKUs);

        // Log the selected SKUs to the console
        console.log("Selected Pipe SKUs:", selectedSkus);
    }

    // Optional: Initialize BranchAndBound with selected SKUs and product types
    // const branchAndBound = new BranchAndBound(selectedSkus, selectedProductTypes);
});

