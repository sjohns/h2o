/**
 * Utility functions for processing packing data for SKUs.
 * 
 * Overview:
 * The function `processPackingData` processes packing data to determine optimal configurations. It filters out inactive product types, SKUs, 
 * and bundles, modifies the SKU field to include the product type name, and returns an object containing only the processed SKUs.
 * 
 * Data Source:
 * The data used for these calculations is sourced from an input data object containing product types, SKUs, and bundles.
 * 
 * Functions:
 * - processPackingData(data): Processes the input data to filter and modify SKUs.
 * 
 * Example Usage:
 * const packingData = {
 *     date: '2024-05-29',
 *     lcm: 'some_value',
 *     productTypes: {
 *         // Product types data structure...
 *     }
 * };
 * 
 * try {
 *     const processedSizes = processPackingData(packingData);
 *     console.log("Processed Sizes:", processedSizes);
 *     console.log("Modified Packing Data:", packingData);
 * } catch (error) {
 *     console.error('Error processing packing data:', error);
 * }
 * 
 * Date: 2024-06-26
 * Author: Stephen Johns
 */

/**
 * Function Description:
 * processPackingData:
 * - Takes in a data object containing product types, skus, and bundles.
 * - Filters out inactive product types, skus, and bundles based on 'Active' flags (case-insensitive).
 * - Deletes product types and skus that do not have any active skus or bundles, respectively.
 * - Prepends the product type to the sku field with a space in between.
 * - Returns an object containing only the processed skus.
 * 
 * Variables:
 * - date: Extracted date from the input data.
 * - lcm: Extracted lcm from the input data.
 * - processedSizes: Object containing the processed skus after filtering and modifications.
 *
 * Steps Performed by processPackingData:
 * 
 * 1. Validation:
 *    - The function first checks if the input data is a valid object containing productTypes. If not, it throws an error.
 *    
 *      if (!data || typeof data !== 'object' || !data.productTypes) {
 *          throw new Error('Invalid input data');
 *      }
 * 
 * 2. Initialization:
 *    - An empty object processedSizes is created to store the processed skus.
 *    
 *      const processedSizes = {};
 * 
 * 3. Iterating Through Product Types:
 *    - The function iterates through each productType in data.productTypes.
 *    
 *      for (const productTypeId in data.productTypes) {
 *          const productType = data.productTypes[productTypeId];
 * 
 *      - Filtering Inactive Product Types:
 *        - Product types with productTypeActive flag set to 'N' (case-insensitive) are skipped and deleted from data.
 *        
 *          if (productType.productTypeActive.toLowerCase() !== 'y') {
 *              delete data.productTypes[productTypeId];
 *              continue;
 *          }
 * 
 * 4. Iterating Through Sizes:
 *    - The function iterates through each sku in the current productType.
 *    
 *      for (const skuId in productType.skus) {
 *          const sku = productType.skus[skuId];
 * 
 *      - Filtering Inactive Sizes:
 *        - Sizes with skuActive flag set to 'N' (case-insensitive) are skipped and deleted from the current productType.
 *        
 *          if (sku.skuActive.toLowerCase() !== 'y') {
 *              delete productType.skus[skuId];
 *              continue;
 *          }
 * 
 * 5. Iterating Through Bundles:
 *    - The function iterates through each bundle in the current sku.
 *    
 *      for (const bundleId in sku.bundles) {
 *          const bundle = sku.bundles[bundleId];
 * 
 *      - Filtering Inactive Bundles:
 *        - Bundles with bundleActive flag set to 'N' (case-insensitive) are skipped and deleted from the current sku.
 *        
 *          if (bundle.bundleActive.toLowerCase() !== 'y') {
 *              delete sku.bundles[bundleId];
 *          }
 * 
 * 6. Deleting Empty Sizes:
 *    - After processing the bundles, skus without any active bundles are deleted from the current productType.
 *    
 *      if (Object.keys(sku.bundles).length === 0) {
 *          delete productType.skus[skuId];
 *          continue;
 *      }
 * 
 * 7. Modifying the Size Field:
 *    - The sku field of each sku is modified to include the productTypeName prepended to it.
 *    
 *      sku.sku = `${productType.productTypeName} ${sku.sku}`;
 * 
 * 8. Adding Processed Size to Result:
 *    - The processed sku is added to the processedSizes object.
 *    
 *      processedSizes[skuId] = sku;
 * 
 * 9. Deleting Empty Product Types:
 *    - After processing the skus, product types without any active skus are deleted from data.
 *    
 *      if (Object.keys(productType.skus).length === 0) {
 *          delete data.productTypes[productTypeId];
 *      }
 * 
 * 10. Returning Processed Sizes:
 *     - The function returns the processedSizes object containing the filtered and modified skus.
 *     
 *       return processedSizes;
 * 
 * Example Usage:
 * 
 * const packingData = {
 *     date: '2024-05-29',
 *     lcm: 'some_value',
 *     productTypes: {
 *         // Product types data structure...
 *     }
 * };
 * 
 * try {
 *     const processedSizes = processPackingData(packingData);
 *     console.log("Processed Sizes:", processedSizes);
 *     console.log("Modified Packing Data:", packingData);
 * } catch (error) {
 *     console.error('Error processing packing data:', error);
 * }
 * 
 * Output:
 * - Processed Sizes: An object containing the active and modified skus.
 * - Modified Packing Data: The input packingData object with inactive or empty entities removed.
 */

// Extract date and lcm into 
const { date } = packingData;

/**
 * Processes packing data to find optimal configurations.
 * 
 * @param {Object} data - The data object containing product types, SKUs, and bundles.
 * @returns {Object} - The processed SKUs.
 * @throws {Error} - If the input data is invalid.
 */
function processPackingData(data) {
    // Validation: Ensure the input data is valid
    if (!data || typeof data !== 'object' || !data.productTypes) {
        throw new Error('Invalid input data');
    }

    // Initialize an empty object to store the processed SKUs
    const processedSizes = {};

    // Iterate through the product types
    for (const productTypeId in data.productTypes) {
        const productType = data.productTypes[productTypeId];

        // Skip inactive product types (case-insensitive check)
        if (productType.productTypeActive.toLowerCase() !== 'y') {
            delete data.productTypes[productTypeId];
            continue;
        }

        // Iterate through the SKUs
        for (const skuId in productType.skus) {
            const sku = productType.skus[skuId];

            // Skip inactive SKUs (case-insensitive check)
            if (sku.skuActive.toLowerCase() !== 'y') {
                delete productType.skus[skuId];
                continue;
            }

            // Iterate through the bundles
            for (const bundleId in sku.bundles) {
                const bundle = sku.bundles[bundleId];

                // Skip inactive bundles (case-insensitive check)
                if (bundle.bundleActive.toLowerCase() !== 'y') {
                    delete sku.bundles[bundleId];
                }
            }

            // Delete SKUs without bundles
            if (Object.keys(sku.bundles).length === 0) {
                delete productType.skus[skuId];
                continue;
            }

            // Prepend the productType to the SKU field
//            sku.sku = `${productType.productType} ${sku.sku}`;

            // Add the SKU to the processedSizes object
            processedSizes[skuId] = sku;
        }

        // Delete product types without SKUs
        if (Object.keys(productType.skus).length === 0) {
            delete data.productTypes[productTypeId];
        }
    }

    return processedSizes;
}
/*
// Example usage:
const packingData = {
    date: '2024-05-29',
    lcm: 'some_value',
    productTypes: {
        // Product types data structure...
    }
};

try {
    const processedSizes = processPackingData(packingData);
    console.log("Processed Sizes:", processedSizes);
    console.log("Modified Packing Data:", packingData);
} catch (error) {
    console.error('Error processing packing data:', error);
}
*/
