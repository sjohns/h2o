/**
 * Class Description:
 * OrderTable:
 * - This class handles the creation and management of an order table and a packing slip.
 * - It initializes with a list of SKUs, a solution, and a branch and bound engine.
 * - It dynamically generates table rows for the order table and the packing slip based on the provided SKUs and solution.
 * - The class also includes methods for handling button clicks to increase or decrease bundle amounts.
 * - The class ensures the correct calculation and display of total sticks per SKU.

 * Variables:
 * - skus: An object containing SKU information.
 * - solution: An array containing the solution for the SKUs.
 * - branchAndBoundEngine: An instance of the branch and bound engine.

 * Methods:
 * - createTableCell(content, isElement = false): Creates a table cell with the given content.
 * - handleButtonClick(skuId, action): Handles button click events for increasing or decreasing bundle amounts.
 * - createTableRow(skuId, description, numberOfBundles): Creates a table row for the order table.
 * - createOrderTable(): Creates the order table with the current SKUs and solution.
 * - createPackingSlip(): Creates the packing slip table with the combined SKU and solution data.
 * - updateAll(skuId, action, totalBundles): Updates all relevant parts of the system based on the action performed.
 * - initializeOrderTable(): Initializes the order table and packing slip by creating them.

 * Steps Performed by OrderTable:

 * 1. Constructor:
 *    - Initializes the OrderTable class with SKUs, solution, and the branch and bound engine.
 *    - Calls initializeOrderTable() to create the order table and packing slip.
 *
 *      constructor(skus, solution, branchAndBoundEngine) {
 *          this.skus = skus;
 *          this.solution = solution;
 *          this.branchAndBoundEngine = branchAndBoundEngine;
 *          this.initializeOrderTable();
 *      }
 *
 * 2. Create Table Cell:
 *    - Creates a table cell with the given content.
 *    - If isElement is true, appends the content as an HTML element; otherwise, sets the text content.
 *
 *      createTableCell(content, isElement = false) {
 *          const cell = document.createElement('td');
 *          if (isElement) {
 *              cell.appendChild(content);
 *          } else {
 *              cell.textContent = content;
 *          }
 *          return cell;
 *      }
 *
 * 3. Handle Button Click:
 *    - Handles button click events for increasing or decreasing bundle amounts.
 *    - Retrieves the total bundles from the row and calls updateAll() with the appropriate parameters.
 *
 *      handleButtonClick(skuId, action) {
 *          const row = document.getElementById(`orderTableDataRowId${skuId}`);
 *          const totalBundles = row.getAttribute('data-total-bundles');
 *          this.updateAll(skuId, action, totalBundles);
 *      }
 *
 * 4. Create Table Row:
 *    - Creates a table row for the order table with the given SKU ID, description, and number of bundles.
 *    - Adds event listeners to the checkbox, increase button, and decrease button.
 *
 *      createTableRow(skuId, description, numberOfBundles) {
 *          const row = document.createElement('tr');
 *          row.setAttribute('id', `orderTableDataRowId${skuId}`);
 *          row.setAttribute('data-sku-id', skuId);
 *          row.setAttribute('data-total-bundles', numberOfBundles);
 *          row.setAttribute('data-action', 'none');
 *          row.classList.add('orderTableDataRow');
 *
 *          const correctAmountCheckbox = document.createElement('input');
 *          correctAmountCheckbox.type = 'checkbox';
 *          correctAmountCheckbox.name = 'correctAmount';
 *          correctAmountCheckbox.setAttribute('data-sku-id', skuId);
 *          correctAmountCheckbox.id = `orderTableDataCorrectAmountId${skuId}`;
 *          correctAmountCheckbox.classList.add('orderTableDataCorrectAmount');
 *
 *          correctAmountCheckbox.addEventListener('change', () => {
 *              const action = correctAmountCheckbox.checked ? 'correctAmount' : 'notCorrectAmount';
 *              this.handleButtonClick(skuId, action);
 *          });
 *
 *          const increaseButton = document.createElement('button');
 *          increaseButton.type = 'button';
 *          increaseButton.id = `orderTableDataIncreaseAmountId${skuId}`;
 *          increaseButton.textContent = 'Increase Amount';
 *          increaseButton.classList.add('orderTableDataIncreaseAmount');
 *          increaseButton.addEventListener('click', () => this.handleButtonClick(skuId, 'increase'));
 *
 *          const decreaseButton = document.createElement('button');
 *          decreaseButton.type = 'button';
 *          decreaseButton.id = `orderTableDataDecreaseAmountId${skuId}`;
 *          decreaseButton.textContent = 'Decrease Amount';
 *          decreaseButton.classList.add('orderTableDataDecreaseAmount');
 *          decreaseButton.addEventListener('click', () => this.handleButtonClick(skuId, 'decrease'));
 *
 *          row.appendChild(this.createTableCell(description));
 *          row.appendChild(this.createTableCell(correctAmountCheckbox, true));
 *          row.appendChild(this.createTableCell(increaseButton, true));
 *          row.appendChild(this.createTableCell(decreaseButton, true));
 *
 *          return row;
 *      }
 *
 * 5. Create Order Table:
 *    - Creates the order table with the current SKUs and solution.
 *    - Iterates through the SKUs and the solution to calculate the total sticks per SKU.
 *    - Appends the created rows to the table body.
 *
 *      createOrderTable() {
 *          const tbody = document.getElementById('orderTableTbody');
 *          tbody.innerHTML = ''; // Clear existing rows
 *          for (const skuId in this.skus) {
 *              const sku = this.skus[skuId];
 *              const sticksPerBundle = sku.sticksPerBundle;
 *              let numberOfBundles = 0;
 *              let totalSticks = 0;
 *              console.log('Sku : ', sku);
 *              console.log(`Sticks per Bundle: ${sticksPerBundle}`);
 *
 *              for (let i = 0; i < this.solution.length; i++) {
 *                  if (this.solution[i].skuId === skuId) {
 *                      numberOfBundles = this.solution[i].numberOfBundles;
 *                      console.log(`SKU: ${skuId}, Number of Bundles: ${numberOfBundles}`);
 *
 *                      if (isNaN(numberOfBundles) || isNaN(sticksPerBundle)) {
 *                          console.error(`Invalid number: numberOfBundles: ${numberOfBundles}, sticksPerBundle: ${sticksPerBundle}`);
 *                          totalSticks = 0;
 *                      } else {
 *                          totalSticks = sticksPerBundle * numberOfBundles;
 *                      }
 *                      break;
 *                  }
 *              }
 *
 *              const description = `${sku.SKU}, ${numberOfBundles} bundles, ${totalSticks} sticks`;
 *              console.log('Description: ', description);
 *              tbody.appendChild(this.createTableRow(skuId, description, numberOfBundles));
 *          }
 *
 *          const createOrderButton = document.getElementById('finalizeOrder');
 *          createOrderButton.addEventListener('click', () => {
 *              alert("Place holder");
 *          });
 *      }
 *
 * 6. Create Packing Slip:
 *    - Creates the packing slip table with the combined SKU and solution data.
 *    - Generates the table headers and data rows dynamically.
 *    - Calculates the total sticks for each SKU and appends it to the rows.
 *
 *      createPackingSlip() {
 *          const tbody = document.getElementById('orderTableDetailTbody');
 *          tbody.innerHTML = ''; // Clear existing rows
 *
 *          const combinedData = this.solution.map(solutionItem => {
 *              const sku = this.skus[solutionItem.skuId];
 *              return {
 *                  ...sku,
 *                  numberOfBundles: solutionItem.numberOfBundles,
 *                  totalSticks: sku.sticksPerBundle * solutionItem.numberOfBundles
 *              };
 *          });
 *
 *          const firstSku = combinedData[0];
 *          let headers = Object.keys(firstSku).filter(header => header !== 'productType' && header !== 'product_type');
 *          headers = headers.filter(header => header !== 'SKU');
 *          headers.unshift('SKU');
 *
 *          const headerRow = document.createElement('tr');
 *          headers.forEach(header => {
 *              const headerCell = document.createElement('th');
 *              headerCell.innerHTML = header.replace(/([a-z])([A-Z])/g, '$1<br>$2');
 *              headerRow.appendChild(headerCell);
 *          });
 *
 *          const thTotalSticks = document.createElement('th');
 *          thTotalSticks.innerHTML = 'Total<br>Sticks';
 *          headerRow.appendChild(thTotalSticks);
 *
 *          tbody.appendChild(headerRow);
 *
 *          combinedData.forEach((data, index) => {
 *              const row = document.createElement('tr');
 *              headers.forEach((header, headerIndex) => {
 *                  const td = document.createElement('td');
 *                  if (headerIndex < 3) {
 *                      td.classList.add('left');
 *                  }
 *                  let cellValue = data[header] || '';
 *                  if (headerIndex >= 3 && header !== 'length' && header !== 'data') {
 *                      cellValue = parseInt(cellValue).toLocaleString();
 *                  }
 *                  td.textContent = cellValue;
 *                  row.appendChild(td);
 *              });
 *
 *              const tdTotalSticks = document.createElement('td');
 *              tdTotalSticks.textContent = data.totalSticks.toLocaleString();
 *              row.appendChild(tdTotalSticks);
 *
 *              tbody.appendChild(row);
 *          });
 *
 *          const headerCells = headerRow.querySelectorAll('th');
 *          headerCells.forEach(headerCell => {
 *              headerCell.innerHTML = headerCell.innerHTML.replace(/calculated/gi, 'H2O');
 *          });
 *          headerCells.forEach(headerCell => {
 *              if (headerCell.innerHTML === 'H2O<br>Bundle<br>Size') {
 *                  headerCell.innerHTML = 'H2O<br>Number<br>Bundles';
 *              }
 *          });
 *
 *          console.log('Packing slip created successfully.');
 *      }
 *
 * 7. Update All:
 *    - Updates all relevant parts of the system based on the action performed.
 *    - Calls the updateAll method of the branchAndBoundEngine instance with the SKU ID, action, and total bundles.
 *
 *      updateAll(skuId, action, totalBundles) {
 *          this.branchAndBoundEngine.updateAll(skuId, action, totalBundles);
 *      }
 *
 * 8. Initialize Order Table:
 *    - Initializes the order table and packing slip by creating them.
 *    - Calls createOrderTable() and createPackingSlip() methods.
 *
 *      initializeOrderTable() {
 *          this.createOrderTable();
 *          this.createPackingSlip();
 *      }
 */

class OrderTable {
    /**
     * Constructor: Initializes the OrderTable class with SKUs, solution, and the branch and bound engine.
     * @param {Object} skus - The SKUs containing SKU information.
     * @param {Array} solution - The solution array containing the number of bundles for each SKU.
     * @param {Object} branchAndBoundEngine - The instance of the branch and bound engine.
     */
    constructor(skus, solution, branchAndBoundEngine) {
        this.skus = skus;
        this.solution = solution;
        this.branchAndBoundEngine = branchAndBoundEngine;
        this.initializeOrderTable();
    }

    /**
     * Creates a table cell with the given content.
     * @param {string|HTMLElement} content - The content to be placed in the cell.
     * @param {boolean} isElement - Flag indicating if the content is an HTML element.
     * @return {HTMLElement} The created table cell.
     */
    createTableCell(content, isElement = false) {
        const cell = document.createElement('td');
        if (isElement) {
            cell.appendChild(content);
        } else {
            cell.textContent = content;
        }
        return cell;
    }

    /**
     * Handles button click events for increasing or decreasing bundle amounts.
     * @param {string} skuId - The SKU ID.
     * @param {string} action - The action to be performed (increase, decrease, etc.).
     */
    handleButtonClick(skuId, action) {
        const row = document.getElementById(`orderTableDataRowId${skuId}`);
        const totalBundles = row.getAttribute('data-total-bundles');
        this.updateAll(skuId, action, totalBundles);
    }

    /**
     * Creates a table row for the order table.
     * @param {string} skuId - The SKU ID.
     * @param {string} description - The description of the SKU.
     * @param {number} numberOfBundles - The number of bundles.
     * @return {HTMLElement} The created table row.
     */
    createTableRow(skuId, description, numberOfBundles) {
        const row = document.createElement('tr');
        row.setAttribute('id', `orderTableDataRowId${skuId}`);
        row.setAttribute('data-sku-id', skuId);
        row.setAttribute('data-total-bundles', numberOfBundles);
        row.setAttribute('data-action', 'none');
        row.classList.add('orderTableDataRow');

        // Create and configure checkbox for marking the correct amount.
        const correctAmountCheckbox = document.createElement('input');
        correctAmountCheckbox.type = 'checkbox';
        correctAmountCheckbox.name = 'correctAmount';
        correctAmountCheckbox.setAttribute('data-sku-id', skuId);
        correctAmountCheckbox.id = `orderTableDataCorrectAmountId${skuId}`;
        correctAmountCheckbox.classList.add('orderTableDataCorrectAmount');

        correctAmountCheckbox.addEventListener('change', () => {
            const action = correctAmountCheckbox.checked ? 'correctAmount' : 'notCorrectAmount';
            this.handleButtonClick(skuId, action);
        });

        // Create and configure button for increasing the amount.
        const increaseButton = document.createElement('button');
        increaseButton.type = 'button';
        increaseButton.id = `orderTableDataIncreaseAmountId${skuId}`;
        increaseButton.textContent = 'Increase Amount';
        increaseButton.classList.add('orderTableDataIncreaseAmount');
        increaseButton.addEventListener('click', () => this.handleButtonClick(skuId, 'increase'));

        // Create and configure button for decreasing the amount.
        const decreaseButton = document.createElement('button');
        decreaseButton.type = 'button';
        decreaseButton.id = `orderTableDataDecreaseAmountId${skuId}`;
        decreaseButton.textContent = 'Decrease Amount';
        decreaseButton.classList.add('orderTableDataDecreaseAmount');
        decreaseButton.addEventListener('click', () => this.handleButtonClick(skuId, 'decrease'));

        // Append all created elements to the row.
        row.appendChild(this.createTableCell(description));
        row.appendChild(this.createTableCell(correctAmountCheckbox, true));
        row.appendChild(this.createTableCell(increaseButton, true));
        row.appendChild(this.createTableCell(decreaseButton, true));

        return row;
    }

    /**
     * Creates the order table with the current SKUs and solution.
     */
    createOrderTable() {
        const tbody = document.getElementById('orderTableTbody');
        tbody.innerHTML = ''; // Clear existing rows

        for (const skuId in this.skus) {
            if (this.skus.hasOwnProperty(skuId)) {
                const sku = this.skus[skuId];
                let totalSticks = 0;
                let totalBundles = 0;
                for (const bundleId in sku.bundles) {
                    if (sku.bundles.hasOwnProperty(bundleId)) {
                        const bundle = sku.bundles[bundleId];
                        for (let i = 0; i < this.solution.length; i++) {
                            if (this.solution[i].bundleId === bundleId) {
                                const numberOfBundles = this.solution[i].numberOfBundles;
                                const sticksPerBundle = bundle.calculatedSticksPerBundle * numberOfBundles;
                                totalSticks += sticksPerBundle;
                                totalBundles += numberOfBundles;
                                break;
                            }
                        }
                    }
                }
                const description = `${sku.sku}, ${totalBundles} bundles, ${totalSticks} sticks`;
                tbody.appendChild(this.createTableRow(skuId, description, totalBundles));
            }
        }

        const createOrderButton = document.getElementById('finalizeOrder');
        createOrderButton.addEventListener('click', () => {
            alert("Place holder");
        });
    }

    /**
     * Creates the packing slip table with the combined SKU and solution data.
     */
    createPackingSlip() {
        const tbody = document.getElementById('orderTableDetailTbody');
        tbody.innerHTML = ''; // Clear existing rows

        const productTypeMap = new Map();
        for (const skuId in this.skus) {
            if (this.skus.hasOwnProperty(skuId)) {
                const sku = this.skus[skuId];
                const productTypeId = sku.productTypeId;
                const description = sku.sku.replace(/[^a-zA-Z\s]+$/, ''); // Removing non-alphabetic characters

                if (!productTypeMap.has(productTypeId)) {
                    productTypeMap.set(productTypeId, {
                        description: description,
                        skus: []
                    });
                }
                productTypeMap.get(productTypeId).skus.push(sku);
            }
        }

        const orderedProductTypes = Array.from(productTypeMap.values()).sort((a, b) => a.description.localeCompare(b.description));

        orderedProductTypes.forEach((value, index) => {
            const productTypeId = value.skus[0].productTypeId;
            const productDescription = value.description;

            if (index > 0) {
                const spacingRow = document.createElement('tr');
                const spacingCell = document.createElement('td');
                spacingCell.colSpan = 2;
                spacingCell.style.height = '20px';
                spacingRow.appendChild(spacingCell);
                tbody.appendChild(spacingRow);
            }

            const productRow = document.createElement('tr');
            const productCell = this.createTableCell(`Product Type ID: ${productTypeId}, Description: ${productDescription}`);
            productCell.colSpan = 2;
            productCell.style.textAlign = 'left'; // Left justify
            productRow.appendChild(productCell);
            tbody.appendChild(productRow);

            value.skus.forEach(sku => {
                const skuSpacingRow = document.createElement('tr');
                const skuSpacingCell = document.createElement('td');
                skuSpacingCell.colSpan = 2;
                skuSpacingCell.style.height = '10px';
                skuSpacingRow.appendChild(skuSpacingCell);
                tbody.appendChild(skuSpacingRow);

                let skuDescription = '';

                for (const key in sku) {
                    if (sku.hasOwnProperty(key) && key !== 'bundles' && key !== 'productType' && key !== 'productTypeId' && key !== 'skuActive') {
                        skuDescription += `${key}: ${sku[key]}, `;
                    }
                }

                let totalBundles = 0;
                let totalSticks = 0;
                for (const bundleId in sku.bundles) {
                    if (sku.bundles.hasOwnProperty(bundleId)) {
                        const bundle = sku.bundles[bundleId];
                        for (let i = 0; i < this.solution.length; i++) {
                            if (this.solution[i].bundleId === bundleId) {
                                const numberOfBundles = this.solution[i].numberOfBundles;
                                const sticksPerBundle = bundle.calculatedSticksPerBundle; // Ensure this property matches createOrderTable
                                totalSticks += sticksPerBundle * numberOfBundles;
                                totalBundles += numberOfBundles;
                                break;
                            }
                        }
                    }
                }
                skuDescription += `<strong>totalBundles: ${totalBundles}, totalSticks: ${totalSticks}</strong>`;

                const skuRow = document.createElement('tr');
                const skuCell = document.createElement('td');
                skuCell.colSpan = 2;
                skuCell.style.paddingLeft = '20px';
                skuCell.style.textAlign = 'left'; // Left justify
                skuCell.innerHTML = skuDescription; // Use innerHTML to render HTML tags
                skuRow.appendChild(skuCell);
                tbody.appendChild(skuRow);

                for (const bundleId in sku.bundles) {
                    if (sku.bundles.hasOwnProperty(bundleId)) {
                        const bundle = sku.bundles[bundleId];
                        let bundleDescription = '';

                        for (const key in bundle) {
                            if (bundle.hasOwnProperty(key) && key !== 'productTypeId' && key !== 'skuId' && key !== 'calculatedBundleSize' && key !== 'bundleActive') {
                                bundleDescription += `${key}: ${bundle[key]}, `;
                            }
                        }

                        let numberOfBundles = 0;
                        let numberOfSticks = 0;
                        const sticksPerBundle = bundle.calculatedSticksPerBundle; // Ensure this property matches createOrderTable
                        for (let i = 0; i < this.solution.length; i++) {
                            if (this.solution[i].bundleId === bundleId) {
                                numberOfBundles = this.solution[i].numberOfBundles;
                                numberOfSticks = sticksPerBundle * numberOfBundles;
                                break;
                            }
                        }

                        bundleDescription += `numberOfBundles: <strong>${numberOfBundles}</strong>, numberOfSticks: <strong>${numberOfSticks}</strong>`;

                        const bundleRow = document.createElement('tr');
                        const bundleCell = document.createElement('td');
                        bundleCell.colSpan = 2;
                        bundleCell.style.paddingLeft = '40px';
                        bundleCell.style.textAlign = 'left'; // Left justify
                        bundleCell.innerHTML = bundleDescription; // Use innerHTML to render HTML tags
                        bundleRow.appendChild(bundleCell);
                        tbody.appendChild(bundleRow);
                    }
                }
            });
        });

        for (let i = 0; i < 3; i++) {
            const spacingRow = document.createElement('tr');
            const spacingCell = document.createElement('td');
            spacingCell.colSpan = 2;
            spacingCell.style.height = '20px';
            spacingRow.appendChild(spacingCell);
            tbody.appendChild(spacingRow);
        }
    }

    /**
     * Creates a table cell with the given content.
     * @param {string|HTMLElement} content - The content to be placed in the cell.
     * @param {boolean} isElement - Flag indicating if the content is an HTML element.
     * @return {HTMLElement} The created table cell.
     */
    createTableCell(content, isElement = false) {
        const cell = document.createElement('td');
        if (isElement) {
            cell.appendChild(content);
        } else {
            cell.textContent = content;
        }
        return cell;
    }

    /**
     * Updates all relevant parts of the system based on the action performed.
     * @param {string} skuId - The SKU ID.
     * @param {string} action - The action to be performed.
     * @param {number} totalBundles - The total number of bundles.
     */
    updateAll(skuId, action, totalBundles) {
        this.branchAndBoundEngine.updateAll(skuId, action, totalBundles);
    }

    /**
     * Initializes the order table and packing slip by creating them.
     */
    initializeOrderTable() {
        this.createOrderTable();
        this.createPackingSlip();
    }

    /**
     * Creates an order table for a specific SKU.
     * @param {string} skuId - The SKU ID.
     */
    createOrderTableOneSku(skuId) {
        // Clear the existing order table
        const orderTable = document.getElementById('orderTable');
        if (orderTable) {
            orderTable.innerHTML = ''; // Clear existing content
        } else {
            console.error('Order table not found.');
            return;
        }

        if (this.skus.hasOwnProperty(skuId)) {
            const sku = this.skus[skuId];
            console.log('sku: ', sku);

            const firstBundle = Object.values(sku.bundles)[0];
            console.log('firstBundle: ', firstBundle);

            if (firstBundle) {
                const eagleSticksPerTruckload = firstBundle.eagleSticksPerTruckload;
                if (eagleSticksPerTruckload !== undefined) {
                    const description = `${sku.sku}, ${eagleSticksPerTruckload} sticks`;

                    // Create a header row
                    const headerRow = document.createElement('tr');
                    const headerCell = document.createElement('th');
                    headerCell.textContent = 'SKU Description';
                    headerRow.appendChild(headerCell);
                    orderTable.appendChild(headerRow);

                    // Create a simple table row with one column and one row
                    const row = document.createElement('tr');
                    const cell = document.createElement('td');
                    cell.textContent = description;
                    row.appendChild(cell);
                    orderTable.appendChild(row);
                } else {
                    console.error('eagleSticksPerTruckload not found in the first bundle');
                }
            } else {
                console.error('No bundles found for SKU:', skuId);
            }
        }
    }

    /**
     * Creates detailed order table for a specific SKU.
     * @param {string} skuId - The SKU ID.
     */
    createOrderTableDetailOneSku(skuId) {
        // Clear the existing order table details
        const orderTableDetail = document.getElementById('orderTableDetailTbody');
        if (orderTableDetail) {
            orderTableDetail.innerHTML = ''; // Clear existing content
        } else {
            console.error('Order table detail not found.');
            return;
        }

        if (this.skus.hasOwnProperty(skuId)) {
            const sku = this.skus[skuId];
            console.log('sku: ', sku);

            const firstBundle = Object.values(sku.bundles)[0];
            console.log('firstBundle: ', firstBundle);

            if (firstBundle) {
                const eagleSticksPerTruckload = firstBundle.eagleSticksPerTruckload;
                if (eagleSticksPerTruckload !== undefined) {
                    const description = `${sku.sku}, ${eagleSticksPerTruckload} sticks`;

                    // Create a header row
                    const headerRow = document.createElement('tr');
                    const headers = ['SKU ID', 'SKU Description', 'Size', 'Popularity Score', 'Eagle Sticks Per Truckload'];

                    headers.forEach(headerText => {
                        const headerCell = document.createElement('th');
                        headerCell.textContent = headerText;
                        headerRow.appendChild(headerCell);
                    });

                    orderTableDetail.appendChild(headerRow);

                    // Create a data row
                    const dataRow = document.createElement('tr');
                    const cells = [
                        sku.skuId,
                        sku.sku,
                        sku.size,
                        sku.skuPopularityScore,
                        eagleSticksPerTruckload
                    ];

                    cells.forEach(cellText => {
                        const cell = document.createElement('td');
                        cell.textContent = cellText;
                        dataRow.appendChild(cell);
                    });

                    orderTableDetail.appendChild(dataRow);
                } else {
                    console.error('eagleSticksPerTruckload not found in the first bundle');
                }
            } else {
                console.error('No bundles found for SKU:', skuId);
            }
        }
    }
}

// Example initialization
let orderTable;

