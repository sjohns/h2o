/**
 * Utility class for calculating ratios related to SKUs.
 * 
 * Overview:
 * The `CalculateRatios` class provides methods to calculate normalized weights based on SKU popularity scores and to calculate 
 * differences in popularity score weights for a given set of SKU data.
 * 
 * Data Source:
 * The data used for these calculations is sourced from the provided SKUs object containing SKU information.
 * 
 * Functions:
 * - constructor(skus): Initializes the class with SKUs and calculates the initial target normalized weights.
 * - calculateTargetNormalizedWeightsBySKU(): Calculates the normalized weights based on SKU popularity scores assuming one stick per SKU.
 * - popularityScoreDifference(skuData): Calculates the difference in popularity score weights for a given set of SKU data.
 * 
 * Example Usage:
 * const skus = {
 *     skuId_53: {
 *         skuId: 'skuId_53',
 *         skuActive: 'Y',
 *         sku: '4" SDR35 PVC PIPE GRAVITY SEWER - GASKET',
 *         size: '4"',
 *         skuPopularityScore: 8,
 *         bundles: {
 *             bundleId_29: {
 *                 bundleId: 'bundleId_29',
 *                 bundleActive: 'Y',
 *                 eagleSticksPerBundle: 84,
 *                 eagleSticksPerTruckload: 1512,
 *                 eaglePercentLoadPerLift: 5.6,
 *                 productTypeId: 'productTypeId_9',
 *                 skuId: 'skuId_53',
 *                 calculatedBundlesPerTruckload: 18,
 *                 calculatedBundleSize: 1,
 *                 calculatedSticksPerBundle: 84
 *             }
 *         },
 *         productTypeId: 'productTypeId_9'
 *     }
 * };
 * 
 * const skuData = [
 *     { skuId: 'skuId_53', bundleId: 'bundleId_29', numberOfBundles: 2 }
 * ];
 * 
 * const ratiosCalculator = new CalculateRatios(skus);
 * const scoreDifference = ratiosCalculator.popularityScoreDifference(skuData);
 * console.log("Popularity Score Difference:", scoreDifference);
 * 
 * Date: 2024-06-26
 * Author: Stephen Johns
 */

class CalculateRatios {
    /**
     * Initializes the CalculateRatios class with SKUs and calculates the initial target normalized weights.
     * @param {Object} skus - The SKUs containing SKU information.
     */
    constructor(skus) {
        console.log("Initializing CalculateRatios...");
        this.skus = skus;  // The SKUs containing SKU information
        this.targetNormalized = this.calculateTargetNormalizedWeightsBySKU();  // Calculate the initial target normalized weights
        console.log("SKUs initialized:", this.skus);
        console.log("Target Normalized Weights:", this.targetNormalized);
    }

    /**
     * Calculates the normalized weights based on SKU popularity scores assuming one stick per SKU.
     * @returns {Object} - The normalized weights per SKU.
     */
    calculateTargetNormalizedWeightsBySKU() {
        // Calculate the total popularity score by summing up the popularity scores of one stick for each SKU
        const totalPopularityScore = Object.values(this.skus).reduce((total, sku) => {
            return total + (sku.skuPopularityScore || 0);
        }, 0);
        console.log("Total Popularity Score:", totalPopularityScore);

        // Initialize an empty object to store the normalized weights
        const normalizedWeights = {};

        // Iterate over each SKU to calculate its normalized weight based on one stick's popularity score
        for (const skuId in this.skus) {
            if (this.skus.hasOwnProperty(skuId)) {
                const popularityScore = this.skus[skuId].skuPopularityScore || 0;  // Get the popularity score of one stick
                normalizedWeights[skuId] = popularityScore / totalPopularityScore;  // Calculate the normalized weight
            }
        }
        console.log("Normalized Weights:", normalizedWeights);
        return normalizedWeights;  // Return the normalized weights
    }

    /**
     * Calculates the difference in popularity score weights for a given set of SKU data.
     * @param {Array} skuData - The SKU data containing SKU IDs and their corresponding number of bundles.
     * @returns {number} - The sum of differences in popularity score weights.
     */
    popularityScoreDifference(skuData) {
        // Initialize an empty object to store the total sticks per SKU
        const totalSticksPerSKU = {};

        // Iterate over the SKU data to calculate the total sticks per SKU
        skuData.forEach(data => {
            const sku = this.skus[data.skuId];  // Get the SKU information using the SKU ID
            if (sku) {
                const bundle = sku.bundles[data.bundleId];  // Get the specific bundle information using the bundle ID
                if (bundle) {
                    totalSticksPerSKU[data.skuId] = (totalSticksPerSKU[data.skuId] || 0) + (bundle.eagleSticksPerBundle * data.numberOfBundles);  // Calculate the total sticks for the SKU
                }
            }
        });
        console.log("Total Sticks Per SKU:", totalSticksPerSKU);

        // Calculate the total number of sticks
        const totalSticks = Object.values(totalSticksPerSKU).reduce((total, sticks) => total + sticks, 0);
        console.log("Total Sticks:", totalSticks);

        // Initialize an empty object to store the normalized weights per SKU
        const normalizedWeightsPerSKU = {};

        // Iterate over the total sticks per SKU to calculate the normalized weights
        for (const skuId in totalSticksPerSKU) {
            if (totalSticksPerSKU.hasOwnProperty(skuId)) {
                normalizedWeightsPerSKU[skuId] = totalSticksPerSKU[skuId] / totalSticks;  // Calculate the normalized weight for the SKU
            }
        }
        console.log("Normalized Weights Per SKU:", normalizedWeightsPerSKU);

        // Initialize the difference sum to 0
        let differenceSum = 0;

        // Iterate over the normalized weights per SKU to calculate the difference sum
        for (const skuId in normalizedWeightsPerSKU) {
            if (normalizedWeightsPerSKU.hasOwnProperty(skuId)) {
                const weight = normalizedWeightsPerSKU[skuId];  // Get the normalized weight for the SKU
                const targetWeight = this.targetNormalized[skuId] || 0;  // Get the target normalized weight, defaulting to 0 if not present
                const popularityScore = this.skus[skuId].skuPopularityScore || 0;  // Get the popularity score of one stick, defaulting to 0 if not present
                differenceSum += Math.abs(targetWeight - weight) * popularityScore;  // Calculate the weighted difference and add it to the difference sum
            }
        }
        console.log("Difference Sum:", differenceSum);

        return differenceSum;  // Return the difference sum
    }
}

/*
// Example usage and testing the class
const skus = {
    skuId_53: {
        skuId: 'skuId_53',
        skuActive: 'Y',
        sku: '4" SDR35 PVC PIPE GRAVITY SEWER - GASKET',
        size: '4"',
        skuPopularityScore: 8,
        bundles: {
            bundleId_29: {
                bundleId: 'bundleId_29',
                bundleActive: 'Y',
                eagleSticksPerBundle: 84,
                eagleSticksPerTruckload: 1512,
                eaglePercentLoadPerLift: 5.6,
                productTypeId: 'productTypeId_9',
                skuId: 'skuId_53',
                calculatedBundlesPerTruckload: 18,
                calculatedBundleSize: 1,
                calculatedSticksPerBundle: 84
            }
        },
        productTypeId: 'productTypeId_9'
    }
};

const skuData = [
    { skuId: 'skuId_53', bundleId: 'bundleId_29', numberOfBundles: 2 }
];

const ratiosCalculator = new CalculateRatios(skus);
const scoreDifference = ratiosCalculator.popularityScoreDifference(skuData);
console.log("Popularity Score Difference:", scoreDifference);
*/

