const packingData = {
    "date": "2024-07-11_15-31-35",
    "productTypes": {
        "productTypeId_1": {
            "productTypeId": "productTypeId_1",
            "productTypeActive": "Y",
            "productTypeLengthStick": "20'",
            "productType": "DR14 PVC PIPE C-900 - GASKET",
            "skus": {
                "skuId_1": {
                    "skuId": "skuId_1",
                    "skuActive": "Y",
                    "sku": "12\" DR14 PVC PIPE C-900 - GASKET",
                    "size": "12\"",
                    "skuPopularityScore": 10.0,
                    "bundles": {
                        "bundleId_26": {
                            "bundleId": "bundleId_26",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 6.0,
                            "eagleSticksPerTruckload": 98.0,
                            "eaglePercentLoadPerLift": 7.1,
                            "productTypeId": "productTypeId_1",
                            "skuId": "skuId_1"
                        }
                    },
                    "productTypeId": "productTypeId_1"
                }
            }
        },
        "productTypeId_2": {
            "productTypeId": "productTypeId_2",
            "productTypeActive": "Y",
            "productTypeLengthStick": "20'",
            "productType": "DR18 PVC PIPE C-900 - GASKET",
            "skus": {
                "skuId_2": {
                    "skuId": "skuId_2",
                    "skuActive": "Y",
                    "sku": "4\" DR18 PVC PIPE C-900 - GASKET",
                    "size": "4\"",
                    "skuPopularityScore": 9.0,
                    "bundles": {
                        "bundleId_16": {
                            "bundleId": "bundleId_16",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 60.0,
                            "eagleSticksPerTruckload": 720.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_2"
                        }
                    },
                    "productTypeId": "productTypeId_2"
                },
                "skuId_3": {
                    "skuId": "skuId_3",
                    "skuActive": "Y",
                    "sku": "10\" DR18 PVC PIPE C-900 - GASKET",
                    "size": "10\"",
                    "skuPopularityScore": 9.0,
                    "bundles": {
                        "bundleId_21": {
                            "bundleId": "bundleId_21",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 16.0,
                            "eagleSticksPerTruckload": 128.0,
                            "eaglePercentLoadPerLift": 12.5,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_3"
                        }
                    },
                    "productTypeId": "productTypeId_2"
                },
                "skuId_4": {
                    "skuId": "skuId_4",
                    "skuActive": "Y",
                    "sku": "12\" DR18 PVC PIPE C-900 - GASKET",
                    "size": "12\"",
                    "skuPopularityScore": 10.0,
                    "bundles": {
                        "bundleId_22": {
                            "bundleId": "bundleId_22",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 6.0,
                            "eagleSticksPerTruckload": 98.0,
                            "eaglePercentLoadPerLift": 6.1,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_4"
                        },
                        "bundleId_23": {
                            "bundleId": "bundleId_23",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 8.0,
                            "eagleSticksPerTruckload": 98.0,
                            "eaglePercentLoadPerLift": 8.2,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_4"
                        },
                        "bundleId_24": {
                            "bundleId": "bundleId_24",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 9.0,
                            "eagleSticksPerTruckload": 98.0,
                            "eaglePercentLoadPerLift": 9.2,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_4"
                        },
                        "bundleId_25": {
                            "bundleId": "bundleId_25",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 12.0,
                            "eagleSticksPerTruckload": 98.0,
                            "eaglePercentLoadPerLift": 12.2,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_4"
                        },
                        "bundleId_27": {
                            "bundleId": "bundleId_27",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 8.0,
                            "eagleSticksPerTruckload": 98.0,
                            "eaglePercentLoadPerLift": 9.5,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_4"
                        }
                    },
                    "productTypeId": "productTypeId_2"
                },
                "skuId_5": {
                    "skuId": "skuId_5",
                    "skuActive": "Y",
                    "sku": "6\" DR18 PVC PIPE C-900 - GASKET",
                    "size": "6\"",
                    "skuPopularityScore": 10.0,
                    "bundles": {
                        "bundleId_17": {
                            "bundleId": "bundleId_17",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 28.0,
                            "eagleSticksPerTruckload": 336.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_5"
                        }
                    },
                    "productTypeId": "productTypeId_2"
                },
                "skuId_6": {
                    "skuId": "skuId_6",
                    "skuActive": "Y",
                    "sku": "8\" DR18 PVC PIPE C-900 - GASKET",
                    "size": "8\"",
                    "skuPopularityScore": 6.0,
                    "bundles": {
                        "bundleId_18": {
                            "bundleId": "bundleId_18",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 15.0,
                            "eagleSticksPerTruckload": 200.0,
                            "eaglePercentLoadPerLift": 7.5,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_6"
                        },
                        "bundleId_19": {
                            "bundleId": "bundleId_19",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 20.0,
                            "eagleSticksPerTruckload": 200.0,
                            "eaglePercentLoadPerLift": 10.0,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_6"
                        },
                        "bundleId_20": {
                            "bundleId": "bundleId_20",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 15.0,
                            "eagleSticksPerTruckload": 200.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_2",
                            "skuId": "skuId_6"
                        }
                    },
                    "productTypeId": "productTypeId_2"
                }
            }
        },
        "productTypeId_3": {
            "productTypeId": "productTypeId_3",
            "productTypeActive": "Y",
            "productTypeLengthStick": "20'",
            "productType": "PVC PIPE 80 - BELL END",
            "skus": {
                "skuId_7": {
                    "skuId": "skuId_7",
                    "skuActive": "Y",
                    "sku": "1 1/2\" PVC PIPE 80 - BELL END",
                    "size": "1 1/2\"",
                    "skuPopularityScore": 15.0,
                    "bundles": {
                        "bundleId_50": {
                            "bundleId": "bundleId_50",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 180.0,
                            "eagleSticksPerTruckload": 4320.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_3",
                            "skuId": "skuId_7"
                        }
                    },
                    "productTypeId": "productTypeId_3"
                }
            }
        },
        "productTypeId_4": {
            "productTypeId": "productTypeId_4",
            "productTypeActive": "Y",
            "productTypeLengthStick": "20'",
            "productType": "PVC PIPE SCH 40 - BELL END",
            "skus": {
                "skuId_10": {
                    "skuId": "skuId_10",
                    "skuActive": "Y",
                    "sku": "2 1/2\" PVC PIPE SCH 40 - BELL END",
                    "size": "2 1/2\"",
                    "skuPopularityScore": 4.0,
                    "bundles": {
                        "bundleId_7": {
                            "bundleId": "bundleId_7",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 73.0,
                            "eagleSticksPerTruckload": 1752.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_10"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_11": {
                    "skuId": "skuId_11",
                    "skuActive": "Y",
                    "sku": "3\" PVC PIPE SCH 40 - BELL END",
                    "size": "3\"",
                    "skuPopularityScore": 4.0,
                    "bundles": {
                        "bundleId_8": {
                            "bundleId": "bundleId_8",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 75.0,
                            "eagleSticksPerTruckload": 1200.0,
                            "eaglePercentLoadPerLift": 6.3,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_11"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_12": {
                    "skuId": "skuId_12",
                    "skuActive": "Y",
                    "sku": "1/2\" PVC PIPE SCH 40 - BELL END",
                    "size": "1/2\"",
                    "skuPopularityScore": 2.0,
                    "bundles": {
                        "bundleId_1": {
                            "bundleId": "bundleId_1",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 360.0,
                            "eagleSticksPerTruckload": 12960.0,
                            "eaglePercentLoadPerLift": 2.8,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_12"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_13": {
                    "skuId": "skuId_13",
                    "skuActive": "Y",
                    "sku": "8\" PVC PIPE SCH 40 - BELL END",
                    "size": "8\"",
                    "skuPopularityScore": 9.0,
                    "bundles": {
                        "bundleId_11": {
                            "bundleId": "bundleId_11",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 15.0,
                            "eagleSticksPerTruckload": 180.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_13"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_14": {
                    "skuId": "skuId_14",
                    "skuActive": "Y",
                    "sku": "1\" PVC PIPE SCH 40 - BELL END",
                    "size": "1\"",
                    "skuPopularityScore": 2.0,
                    "bundles": {
                        "bundleId_3": {
                            "bundleId": "bundleId_3",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 280.0,
                            "eagleSticksPerTruckload": 5600.0,
                            "eaglePercentLoadPerLift": 5.0,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_14"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_15": {
                    "skuId": "skuId_15",
                    "skuActive": "Y",
                    "sku": "6\" PVC PIPE SCH 40 - BELL END",
                    "size": "6\"",
                    "skuPopularityScore": 8.0,
                    "bundles": {
                        "bundleId_10": {
                            "bundleId": "bundleId_10",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 26.0,
                            "eagleSticksPerTruckload": 312.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_15"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_16": {
                    "skuId": "skuId_16",
                    "skuActive": "Y",
                    "sku": "1 1/4\" PVC PIPE SCH 40 - BELL END",
                    "size": "1 1/4\"",
                    "skuPopularityScore": 2.0,
                    "bundles": {
                        "bundleId_4": {
                            "bundleId": "bundleId_4",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 220.0,
                            "eagleSticksPerTruckload": 5280.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_16"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_17": {
                    "skuId": "skuId_17",
                    "skuActive": "Y",
                    "sku": "1 1/2\" PVC PIPE SCH 40 - BELL END",
                    "size": "1 1/2\"",
                    "skuPopularityScore": 2.0,
                    "bundles": {
                        "bundleId_5": {
                            "bundleId": "bundleId_5",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 180.0,
                            "eagleSticksPerTruckload": 4320.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_17"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_18": {
                    "skuId": "skuId_18",
                    "skuActive": "Y",
                    "sku": "12\" PVC PIPE SCH 40 - BELL END",
                    "size": "12\"",
                    "skuPopularityScore": 8.0,
                    "bundles": {
                        "bundleId_13": {
                            "bundleId": "bundleId_13",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 6.0,
                            "eagleSticksPerTruckload": 84.0,
                            "eaglePercentLoadPerLift": 7.1,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_18"
                        },
                        "bundleId_14": {
                            "bundleId": "bundleId_14",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 8.0,
                            "eagleSticksPerTruckload": 84.0,
                            "eaglePercentLoadPerLift": 9.5,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_18"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_19": {
                    "skuId": "skuId_19",
                    "skuActive": "Y",
                    "sku": "10\" PVC PIPE SCH 40 - BELL END",
                    "size": "10\"",
                    "skuPopularityScore": 5.0,
                    "bundles": {
                        "bundleId_12": {
                            "bundleId": "bundleId_12",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 12.0,
                            "eagleSticksPerTruckload": 144.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_19"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_20": {
                    "skuId": "skuId_20",
                    "skuActive": "Y",
                    "sku": "4\" PVC PIPE SCH 40 - BELL END",
                    "size": "4\"",
                    "skuPopularityScore": 7.0,
                    "bundles": {
                        "bundleId_9": {
                            "bundleId": "bundleId_9",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 57.0,
                            "eagleSticksPerTruckload": 684.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_20"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_8": {
                    "skuId": "skuId_8",
                    "skuActive": "Y",
                    "sku": "2\" PVC PIPE SCH 40 - BELL END",
                    "size": "2\"",
                    "skuPopularityScore": 1.0,
                    "bundles": {
                        "bundleId_6": {
                            "bundleId": "bundleId_6",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 105.0,
                            "eagleSticksPerTruckload": 2520.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_8"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                },
                "skuId_9": {
                    "skuId": "skuId_9",
                    "skuActive": "Y",
                    "sku": "3/4\" PVC PIPE SCH 40 - BELL END",
                    "size": "3/4\"",
                    "skuPopularityScore": 7.0,
                    "bundles": {
                        "bundleId_2": {
                            "bundleId": "bundleId_2",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 400.0,
                            "eagleSticksPerTruckload": 9600.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_4",
                            "skuId": "skuId_9"
                        }
                    },
                    "productTypeId": "productTypeId_4"
                }
            }
        },
        "productTypeId_5": {
            "productTypeId": "productTypeId_5",
            "productTypeActive": "Y",
            "productTypeLengthStick": "20'",
            "productType": "PVC PIPE SCH 80 - BELL END",
            "skus": {
                "skuId_21": {
                    "skuId": "skuId_21",
                    "skuActive": "Y",
                    "sku": "2 1/2\" PVC PIPE SCH 80 - BELL END",
                    "size": "2 1/2\"",
                    "skuPopularityScore": 12.0,
                    "bundles": {
                        "bundleId_52": {
                            "bundleId": "bundleId_52",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 73.0,
                            "eagleSticksPerTruckload": 1752.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_21"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_22": {
                    "skuId": "skuId_22",
                    "skuActive": "Y",
                    "sku": "4\" PVC PIPE SCH 80 - BELL END",
                    "size": "4\"",
                    "skuPopularityScore": 16.0,
                    "bundles": {
                        "bundleId_54": {
                            "bundleId": "bundleId_54",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 57.0,
                            "eagleSticksPerTruckload": 684.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_22"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_23": {
                    "skuId": "skuId_23",
                    "skuActive": "Y",
                    "sku": "1/2\" PVC PIPE SCH 80 - BELL END",
                    "size": "1/2\"",
                    "skuPopularityScore": 14.0,
                    "bundles": {
                        "bundleId_46": {
                            "bundleId": "bundleId_46",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 360.0,
                            "eagleSticksPerTruckload": 12960.0,
                            "eaglePercentLoadPerLift": 2.8,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_23"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_24": {
                    "skuId": "skuId_24",
                    "skuActive": "Y",
                    "sku": "1\" PVC PIPE SCH 80 - BELL END",
                    "size": "1\"",
                    "skuPopularityScore": 11.0,
                    "bundles": {
                        "bundleId_48": {
                            "bundleId": "bundleId_48",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 280.0,
                            "eagleSticksPerTruckload": 5600.0,
                            "eaglePercentLoadPerLift": 5.0,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_24"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_25": {
                    "skuId": "skuId_25",
                    "skuActive": "Y",
                    "sku": "10\" PVC PIPE SCH 80 - BELL END",
                    "size": "10\"",
                    "skuPopularityScore": 8.0,
                    "bundles": {
                        "bundleId_57": {
                            "bundleId": "bundleId_57",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 12.0,
                            "eagleSticksPerTruckload": 144.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_25"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_26": {
                    "skuId": "skuId_26",
                    "skuActive": "Y",
                    "sku": "2\" PVC PIPE SCH 80 - BELL END",
                    "size": "2\"",
                    "skuPopularityScore": 16.0,
                    "bundles": {
                        "bundleId_51": {
                            "bundleId": "bundleId_51",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 105.0,
                            "eagleSticksPerTruckload": 2520.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_26"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_27": {
                    "skuId": "skuId_27",
                    "skuActive": "Y",
                    "sku": "8\" PVC PIPE SCH 80 - BELL END",
                    "size": "8\"",
                    "skuPopularityScore": 5.0,
                    "bundles": {
                        "bundleId_56": {
                            "bundleId": "bundleId_56",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 15.0,
                            "eagleSticksPerTruckload": 180.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_27"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_28": {
                    "skuId": "skuId_28",
                    "skuActive": "Y",
                    "sku": "3\" PVC PIPE SCH 80 - BELL END",
                    "size": "3\"",
                    "skuPopularityScore": 15.0,
                    "bundles": {
                        "bundleId_53": {
                            "bundleId": "bundleId_53",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 75.0,
                            "eagleSticksPerTruckload": 1200.0,
                            "eaglePercentLoadPerLift": 6.3,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_28"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_29": {
                    "skuId": "skuId_29",
                    "skuActive": "Y",
                    "sku": "1 1/4\" PVC PIPE SCH 80 - BELL END",
                    "size": "1 1/4\"",
                    "skuPopularityScore": 14.0,
                    "bundles": {
                        "bundleId_49": {
                            "bundleId": "bundleId_49",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 220.0,
                            "eagleSticksPerTruckload": 5280.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_29"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_30": {
                    "skuId": "skuId_30",
                    "skuActive": "Y",
                    "sku": "12\" PVC PIPE SCH 80 - BELL END",
                    "size": "12\"",
                    "skuPopularityScore": 9.0,
                    "bundles": {
                        "bundleId_58": {
                            "bundleId": "bundleId_58",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 6.0,
                            "eagleSticksPerTruckload": 84.0,
                            "eaglePercentLoadPerLift": 7.1,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_30"
                        },
                        "bundleId_59": {
                            "bundleId": "bundleId_59",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 8.0,
                            "eagleSticksPerTruckload": 84.0,
                            "eaglePercentLoadPerLift": 9.5,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_30"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_31": {
                    "skuId": "skuId_31",
                    "skuActive": "Y",
                    "sku": "3/4\" PVC PIPE SCH 80 - BELL END",
                    "size": "3/4\"",
                    "skuPopularityScore": 15.0,
                    "bundles": {
                        "bundleId_47": {
                            "bundleId": "bundleId_47",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 400.0,
                            "eagleSticksPerTruckload": 9600.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_31"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                },
                "skuId_32": {
                    "skuId": "skuId_32",
                    "skuActive": "Y",
                    "sku": "6\" PVC PIPE SCH 80 - BELL END",
                    "size": "6\"",
                    "skuPopularityScore": 17.0,
                    "bundles": {
                        "bundleId_55": {
                            "bundleId": "bundleId_55",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 26.0,
                            "eagleSticksPerTruckload": 312.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_5",
                            "skuId": "skuId_32"
                        }
                    },
                    "productTypeId": "productTypeId_5"
                }
            }
        },
        "productTypeId_6": {
            "productTypeId": "productTypeId_6",
            "productTypeActive": "Y",
            "productTypeLengthStick": "20'",
            "productType": "SDR13.5 BE - BELL END",
            "skus": {
                "skuId_33": {
                    "skuId": "skuId_33",
                    "skuActive": "Y",
                    "sku": "1/2\" SDR13.5 BE - BELL END",
                    "size": "1/2\"",
                    "skuPopularityScore": 10.0,
                    "bundles": {
                        "bundleId_61": {
                            "bundleId": "bundleId_61",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 360.0,
                            "eagleSticksPerTruckload": 12960.0,
                            "eaglePercentLoadPerLift": 2.8,
                            "productTypeId": "productTypeId_6",
                            "skuId": "skuId_33"
                        }
                    },
                    "productTypeId": "productTypeId_6"
                }
            }
        },
        "productTypeId_7": {
            "productTypeId": "productTypeId_7",
            "productTypeActive": "Y",
            "productTypeLengthStick": "20'",
            "productType": "SDR21 BE - BELL END",
            "skus": {
                "skuId_34": {
                    "skuId": "skuId_34",
                    "skuActive": "Y",
                    "sku": "2\" SDR21 BE - BELL END",
                    "size": "2\"",
                    "skuPopularityScore": 7.0,
                    "bundles": {
                        "bundleId_66": {
                            "bundleId": "bundleId_66",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 105.0,
                            "eagleSticksPerTruckload": 2520.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_34"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_35": {
                    "skuId": "skuId_35",
                    "skuActive": "Y",
                    "sku": "1 1/4\" SDR21 BE - BELL END",
                    "size": "1 1/4\"",
                    "skuPopularityScore": 10.0,
                    "bundles": {
                        "bundleId_64": {
                            "bundleId": "bundleId_64",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 220.0,
                            "eagleSticksPerTruckload": 5280.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_35"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_36": {
                    "skuId": "skuId_36",
                    "skuActive": "Y",
                    "sku": "1 1/2\" SDR21 BE - BELL END",
                    "size": "1 1/2\"",
                    "skuPopularityScore": 11.0,
                    "bundles": {
                        "bundleId_65": {
                            "bundleId": "bundleId_65",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 180.0,
                            "eagleSticksPerTruckload": 4320.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_36"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_37": {
                    "skuId": "skuId_37",
                    "skuActive": "Y",
                    "sku": "8\" SDR21 BE - BELL END",
                    "size": "8\"",
                    "skuPopularityScore": 11.0,
                    "bundles": {
                        "bundleId_71": {
                            "bundleId": "bundleId_71",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 15.0,
                            "eagleSticksPerTruckload": 180.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_37"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_38": {
                    "skuId": "skuId_38",
                    "skuActive": "Y",
                    "sku": "4\" SDR21 BE - BELL END",
                    "size": "4\"",
                    "skuPopularityScore": 12.0,
                    "bundles": {
                        "bundleId_69": {
                            "bundleId": "bundleId_69",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 57.0,
                            "eagleSticksPerTruckload": 684.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_38"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_39": {
                    "skuId": "skuId_39",
                    "skuActive": "Y",
                    "sku": "3/4\" SDR21 BE - BELL END",
                    "size": "3/4\"",
                    "skuPopularityScore": 6.0,
                    "bundles": {
                        "bundleId_62": {
                            "bundleId": "bundleId_62",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 400.0,
                            "eagleSticksPerTruckload": 9600.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_39"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_40": {
                    "skuId": "skuId_40",
                    "skuActive": "Y",
                    "sku": "6\" SDR21 BE - BELL END",
                    "size": "6\"",
                    "skuPopularityScore": 8.0,
                    "bundles": {
                        "bundleId_70": {
                            "bundleId": "bundleId_70",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 26.0,
                            "eagleSticksPerTruckload": 312.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_40"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_41": {
                    "skuId": "skuId_41",
                    "skuActive": "Y",
                    "sku": "1\" SDR21 BE - BELL END",
                    "size": "1\"",
                    "skuPopularityScore": 9.0,
                    "bundles": {
                        "bundleId_63": {
                            "bundleId": "bundleId_63",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 280.0,
                            "eagleSticksPerTruckload": 5600.0,
                            "eaglePercentLoadPerLift": 5.0,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_41"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_42": {
                    "skuId": "skuId_42",
                    "skuActive": "Y",
                    "sku": "2 1/2\" SDR21 BE - BELL END",
                    "size": "2 1/2\"",
                    "skuPopularityScore": 10.0,
                    "bundles": {
                        "bundleId_67": {
                            "bundleId": "bundleId_67",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 73.0,
                            "eagleSticksPerTruckload": 1752.0,
                            "eaglePercentLoadPerLift": 4.2,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_42"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                },
                "skuId_43": {
                    "skuId": "skuId_43",
                    "skuActive": "Y",
                    "sku": "3\" SDR21 BE - BELL END",
                    "size": "3\"",
                    "skuPopularityScore": 11.0,
                    "bundles": {
                        "bundleId_68": {
                            "bundleId": "bundleId_68",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 75.0,
                            "eagleSticksPerTruckload": 1200.0,
                            "eaglePercentLoadPerLift": 6.3,
                            "productTypeId": "productTypeId_7",
                            "skuId": "skuId_43"
                        }
                    },
                    "productTypeId": "productTypeId_7"
                }
            }
        },
        "productTypeId_8": {
            "productTypeId": "productTypeId_8",
            "productTypeActive": "Y",
            "productTypeLengthStick": "14'",
            "productType": "SDR26 PVC PIPE GRAVITY SEWER - GASKET",
            "skus": {
                "skuId_44": {
                    "skuId": "skuId_44",
                    "skuActive": "Y",
                    "sku": "12\" SDR26 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "12\"",
                    "skuPopularityScore": 13.0,
                    "bundles": {
                        "bundleId_43": {
                            "bundleId": "bundleId_43",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 12.0,
                            "eagleSticksPerTruckload": 168.0,
                            "eaglePercentLoadPerLift": 7.1,
                            "productTypeId": "productTypeId_8",
                            "skuId": "skuId_44"
                        },
                        "bundleId_44": {
                            "bundleId": "bundleId_44",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 16.0,
                            "eagleSticksPerTruckload": 168.0,
                            "eaglePercentLoadPerLift": 9.5,
                            "productTypeId": "productTypeId_8",
                            "skuId": "skuId_44"
                        }
                    },
                    "productTypeId": "productTypeId_8"
                },
                "skuId_45": {
                    "skuId": "skuId_45",
                    "skuActive": "Y",
                    "sku": "8\" SDR26 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "8\"",
                    "skuPopularityScore": 14.0,
                    "bundles": {
                        "bundleId_39": {
                            "bundleId": "bundleId_39",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 30.0,
                            "eagleSticksPerTruckload": 396.0,
                            "eaglePercentLoadPerLift": 7.5,
                            "productTypeId": "productTypeId_8",
                            "skuId": "skuId_45"
                        },
                        "bundleId_40": {
                            "bundleId": "bundleId_40",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 36.0,
                            "eagleSticksPerTruckload": 396.0,
                            "eaglePercentLoadPerLift": 9.1,
                            "productTypeId": "productTypeId_8",
                            "skuId": "skuId_45"
                        }
                    },
                    "productTypeId": "productTypeId_8"
                },
                "skuId_46": {
                    "skuId": "skuId_46",
                    "skuActive": "Y",
                    "sku": "6\" SDR26 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "6\"",
                    "skuPopularityScore": 13.0,
                    "bundles": {
                        "bundleId_38": {
                            "bundleId": "bundleId_38",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 40.0,
                            "eagleSticksPerTruckload": 720.0,
                            "eaglePercentLoadPerLift": 5.6,
                            "productTypeId": "productTypeId_8",
                            "skuId": "skuId_46"
                        }
                    },
                    "productTypeId": "productTypeId_8"
                },
                "skuId_47": {
                    "skuId": "skuId_47",
                    "skuActive": "Y",
                    "sku": "10\" SDR26 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "10\"",
                    "skuPopularityScore": 10.0,
                    "bundles": {
                        "bundleId_41": {
                            "bundleId": "bundleId_41",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 12.0,
                            "eagleSticksPerTruckload": 243.0,
                            "eaglePercentLoadPerLift": 5.9,
                            "productTypeId": "productTypeId_8",
                            "skuId": "skuId_47"
                        },
                        "bundleId_42": {
                            "bundleId": "bundleId_42",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 15.0,
                            "eagleSticksPerTruckload": 243.0,
                            "eaglePercentLoadPerLift": 6.2,
                            "productTypeId": "productTypeId_8",
                            "skuId": "skuId_47"
                        }
                    },
                    "productTypeId": "productTypeId_8"
                },
                "skuId_48": {
                    "skuId": "skuId_48",
                    "skuActive": "Y",
                    "sku": "4\" SDR26 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "4\"",
                    "skuPopularityScore": 12.0,
                    "bundles": {
                        "bundleId_37": {
                            "bundleId": "bundleId_37",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 84.0,
                            "eagleSticksPerTruckload": 1512.0,
                            "eaglePercentLoadPerLift": 8.3,
                            "productTypeId": "productTypeId_8",
                            "skuId": "skuId_48"
                        }
                    },
                    "productTypeId": "productTypeId_8"
                }
            }
        },
        "productTypeId_9": {
            "productTypeId": "productTypeId_9",
            "productTypeActive": "Y",
            "productTypeLengthStick": "14'",
            "productType": "SDR35 PVC PIPE GRAVITY SEWER - GASKET",
            "skus": {
                "skuId_49": {
                    "skuId": "skuId_49",
                    "skuActive": "Y",
                    "sku": "8\" SDR35 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "8\"",
                    "skuPopularityScore": 12.0,
                    "bundles": {
                        "bundleId_31": {
                            "bundleId": "bundleId_31",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 30.0,
                            "eagleSticksPerTruckload": 396.0,
                            "eaglePercentLoadPerLift": 7.5,
                            "productTypeId": "productTypeId_9",
                            "skuId": "skuId_49"
                        },
                        "bundleId_32": {
                            "bundleId": "bundleId_32",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 36.0,
                            "eagleSticksPerTruckload": 396.0,
                            "eaglePercentLoadPerLift": 9.1,
                            "productTypeId": "productTypeId_9",
                            "skuId": "skuId_49"
                        }
                    },
                    "productTypeId": "productTypeId_9"
                },
                "skuId_50": {
                    "skuId": "skuId_50",
                    "skuActive": "Y",
                    "sku": "6\" SDR35 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "6\"",
                    "skuPopularityScore": 11.0,
                    "bundles": {
                        "bundleId_30": {
                            "bundleId": "bundleId_30",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 40.0,
                            "eagleSticksPerTruckload": 720.0,
                            "eaglePercentLoadPerLift": 5.6,
                            "productTypeId": "productTypeId_9",
                            "skuId": "skuId_50"
                        }
                    },
                    "productTypeId": "productTypeId_9"
                },
                "skuId_51": {
                    "skuId": "skuId_51",
                    "skuActive": "Y",
                    "sku": "12\" SDR35 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "12\"",
                    "skuPopularityScore": 9.0,
                    "bundles": {
                        "bundleId_35": {
                            "bundleId": "bundleId_35",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 12.0,
                            "eagleSticksPerTruckload": 168.0,
                            "eaglePercentLoadPerLift": 7.1,
                            "productTypeId": "productTypeId_9",
                            "skuId": "skuId_51"
                        },
                        "bundleId_36": {
                            "bundleId": "bundleId_36",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 16.0,
                            "eagleSticksPerTruckload": 168.0,
                            "eaglePercentLoadPerLift": 9.5,
                            "productTypeId": "productTypeId_9",
                            "skuId": "skuId_51"
                        }
                    },
                    "productTypeId": "productTypeId_9"
                },
                "skuId_52": {
                    "skuId": "skuId_52",
                    "skuActive": "Y",
                    "sku": "10\" SDR35 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "10\"",
                    "skuPopularityScore": 13.0,
                    "bundles": {
                        "bundleId_33": {
                            "bundleId": "bundleId_33",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 12.0,
                            "eagleSticksPerTruckload": 243.0,
                            "eaglePercentLoadPerLift": 4.9,
                            "productTypeId": "productTypeId_9",
                            "skuId": "skuId_52"
                        },
                        "bundleId_34": {
                            "bundleId": "bundleId_34",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 15.0,
                            "eagleSticksPerTruckload": 243.0,
                            "eaglePercentLoadPerLift": 6.2,
                            "productTypeId": "productTypeId_9",
                            "skuId": "skuId_52"
                        }
                    },
                    "productTypeId": "productTypeId_9"
                },
                "skuId_53": {
                    "skuId": "skuId_53",
                    "skuActive": "Y",
                    "sku": "4\" SDR35 PVC PIPE GRAVITY SEWER - GASKET",
                    "size": "4\"",
                    "skuPopularityScore": 8.0,
                    "bundles": {
                        "bundleId_29": {
                            "bundleId": "bundleId_29",
                            "bundleActive": "Y",
                            "eagleSticksPerBundle": 84.0,
                            "eagleSticksPerTruckload": 1512.0,
                            "eaglePercentLoadPerLift": 5.6,
                            "productTypeId": "productTypeId_9",
                            "skuId": "skuId_53"
                        }
                    },
                    "productTypeId": "productTypeId_9"
                }
            }
        }
    }
};