
console.log(data);

// Create a function to create the form and table
function createPackingDataForm(data) {

  // Create the form
  const $packingDataForm = jQuery('<form>').attr('id', 'packing_data');

  // Create the table
  const $table = jQuery('<table>').attr('border', 1);

  // Create the table header
  const $tableHeader = jQuery('<tr>');
  const $SKUHeader = jQuery('<th>').text('SKU');
  const $descriptionHeader = jQuery('<th>').text('Part Description');
  const $bundlesHeader = jQuery('<th>').text('Number of Bundles');
  const $sticksPerBundleHeader = jQuery('<th>').text('Sticks Per Bundle');
  const $totalSticksHeader = jQuery('<th>').text('Total Sticks');
  const $bundleSizeHeader = jQuery('<th>').text('Bundle Size');
  const $totalSizeHeader = jQuery('<th>').text('Total Size');

  $tableHeader.append($SKUHeader, $descriptionHeader, $bundlesHeader, $sticksPerBundleHeader, $totalSticksHeader, $bundleSizeHeader, $totalSizeHeader);
  $table.append($tableHeader);

  // Initialize variables for calculations
  let truckLoad = 0;
  let totalRank = 0;

  // Create a row for each SKU
  data.forEach(function(row) {
    // Create the row element
    const $row = jQuery('<tr>');

    // Create the SKU cell
    const $SKUCell = jQuery('<td>').text(row.SKU);
    $row.append($SKUCell);

    // Create the part description cell
    const $partDescriptionCell = jQuery('<td>').text(row.partDescription);
    $row.append($partDescriptionCell);

    // Create the number of bundles input
    const $bundlesInput = jQuery('<input>').attr('type', 'number').attr('name', 'numberOfBundles').attr('value', 0).attr('min', 0).attr('max', row.bundlesPerTruckload).attr('step', 1);
    $row.append($bundlesInput);

    // Create the sticks per bundle cell
    const $sticksPerBundleCell = jQuery('<td>').text(row.sticksPerBundle);
    $row.append($sticksPerBundleCell);

    // Create the total sticks cell
    const $totalSticksCell = jQuery('<td>');
    const $totalSticksInput = jQuery('<input>').attr('type', 'text').attr('name', 'totalSticks').attr('value', 0).attr('readonly', true);
    $totalSticksCell.append($totalSticksInput);
    $row.append($totalSticksCell);

    // Create the bundle size cell
    const $bundleSizeCell = jQuery('<td>').text(row.bundleSize);
    $row.append($bundleSizeCell);

    // Create the total size cell
    const $totalSizeCell = jQuery('<td>');
    const $totalSizeInput = jQuery('<input>').attr('type', 'text').attr('name', 'totalSize[]').attr('value', 0).attr('readonly', true);
    $totalSizeCell.append($totalSizeInput);
    $row.append($totalSizeCell);

    // Calculate 'Total Sticks' and 'Total Size' on input change
    $bundlesInput.on('input', function(event) {
      const calculatedTotalSticks = event.target.value * row.sticksPerBundle;
      $totalSticksInput.val(calculatedTotalSticks);

      const calculatedTotalSize = event.target.value * row.bundleSize;
      $totalSizeInput.val(calculatedTotalSize);
    });

    $table.append($row);
  });

  $packingDataForm.append($table);
  jQuery('body').append($packingDataForm);
}

// Call the function to create the form and table
createPackingDataForm(data);

