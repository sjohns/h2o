
const packingData = {
    "date": "2023-10-29_17-52-03",
    "lcm": 720,
    "parts": [
        {
            "SKU": "1CESF40013SH",
            "partDescription": "1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 360,
            "bundlesPerTruckload": 36,
            "bundleSize": 20,
            "rank": 5
        },
        {
            "SKU": "1CESF40019SH",
            "partDescription": "3/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 400,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 10
        },
        {
            "SKU": "1CESF40025SH",
            "partDescription": "1\" PVC PIPE SCH 40",
            "sticksPerBundle": 280,
            "bundlesPerTruckload": 20,
            "bundleSize": 36,
            "rank": 10
        },
        {
            "SKU": "1 1/4\" PVC PIPE SCH 40",
            "partDescription": "1 1/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 220,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 10
        },
        {
            "SKU": "1CESF40038SH",
            "partDescription": "1 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 180,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 2
        },
        {
            "SKU": "1CESF40050SH",
            "partDescription": "2\" PVC PIPE SCH 40",
            "sticksPerBundle": 105,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 1
        },
        {
            "SKU": "1CESF40060SH",
            "partDescription": "2 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 73,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 3
        },
        {
            "SKU": "1CESF40075SH",
            "partDescription": "3\" PVC PIPE SCH 40",
            "sticksPerBundle": 75,
            "bundlesPerTruckload": 16,
            "bundleSize": 45,
            "rank": 4
        },
        {
            "SKU": "1CESF40100SH",
            "partDescription": "4\" PVC PIPE SCH 40",
            "sticksPerBundle": 57,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 6
        },
        {
            "SKU": "6\" PVC PIPE SCH 40",
            "partDescription": "6\" PVC PIPE SCH 40",
            "sticksPerBundle": 26,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 7
        },
        {
            "SKU": "8\" PVC PIPE SCH 40",
            "partDescription": "8\" PVC PIPE SCH 40",
            "sticksPerBundle": 15,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 8
        },
        {
            "SKU": "10\" PVC PIPE SCH 40",
            "partDescription": "10\" PVC PIPE SCH 40",
            "sticksPerBundle": 12,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 10
        }
    ]
};

console.log('packingData = ',packingData);

// Create a variable to store the selected SKUs
let selectedSKUs = [];
let constraints = {};
// Function to create constraints based on selected SKUs
function createConstraints(selectedSKUs, allParts, existingConstraints) {
    selectedSKUs.forEach(selectedSKU => {
        const matchingPart = allParts.find(part => part.SKU === selectedSKU);
        if (matchingPart) {
            existingConstraints[selectedSKU] = {
                minNumberOfBundles: 1,
                maxNumberOfBundles: matchingPart.bundlesPerTruckload
            };
        }
    });
}

// Function to extract data based on selected SKUs
function extractData(selectedSKUs, allParts) {
    const data = selectedSKUs.map(selectedSKU => {
        const matchingPart = allParts.find(part => part.SKU === selectedSKU);
        return matchingPart ? { ...matchingPart } : null;
    }).filter(data => data !== null);
    return data;
}

// JavaScript code to create the form and add rows for each SKU
function createPackingDataForm(SKUs) {
    const packingDataForm = document.createElement('form');
    packingDataForm.id = 'select_SKUs';

    const table = document.createElement('table');
    table.border = '1';

    const tableHeader = document.createElement('tr');
    const headers = ['Part Description', 'Select'];

    headers.forEach(headerText => {
        const header = document.createElement('th');
        header.textContent = headerText;
        tableHeader.appendChild(header);
    });

    table.appendChild(tableHeader);

    SKUs.forEach(sku => {
        const row = document.createElement('tr');

        // Part Description
        const partDescriptionCell = document.createElement('td');
        partDescriptionCell.textContent = sku.partDescription;
        row.appendChild(partDescriptionCell);

        // Create a checkbox cell
        const selectCell = document.createElement('td');
        const selectCheckbox = document.createElement('input');
        selectCheckbox.type = 'checkbox';
        selectCheckbox.name = 'selectedSKUs';
        selectCheckbox.value = sku.SKU; // Use SKU as the checkbox value
        selectCell.appendChild(selectCheckbox);
        row.appendChild(selectCell);

        table.appendChild(row);
    });

    packingDataForm.appendChild(table);

    // Add a submit button to submit the form
    const submitButton = document.createElement('input');
    submitButton.type = 'submit';
    submitButton.value = 'Submit';
    packingDataForm.appendChild(submitButton);

    // Add an event listener to the form to handle form submission
    packingDataForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent the default form submission

        // Retrieve selected SKUs here
        const selectedSKUs = Array.from(packingDataForm.querySelectorAll('input[name=selectedSKUs]:checked')).map(checkbox => checkbox.value);

        // Check if at least one SKU is selected
        if (selectedSKUs.length === 0) {
            alert('Please select at least one SKU before submitting.');
        } else {
            console.log('Selected SKUs:', selectedSKUs);
//            // You can call your matchData function here with the selected SKUs and the 'parts' array
           // Extract and return the data based on selected SKUs
    createConstraints(selectedSKUs, packingData.parts, constraints);
    console.log('Updated Constraints:', constraints);
    localStorage.setItem('constraints', JSON.stringify(constraints));
 
            const data = extractData(selectedSKUs, packingData.parts);
            console.log('Data:', data);



            // Reset the form after submission
            packingDataForm.reset();        }
    });

    document.body.appendChild(packingDataForm);
}

document.addEventListener('DOMContentLoaded', function() {
	// Call the function to create the form and add rows for each SKU, passing the allSKUs array
	createPackingDataForm(packingData.parts);
	});
	

