const selectedSKUs = [
  "1CESF40013SH",
  "1CESF40019SH",
  "1CESF40025SH"
];

//console.log('selectedSKUs', selectedSKUs);
