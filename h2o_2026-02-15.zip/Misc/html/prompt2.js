function branchAndBound(data, initial_selection) {
  //alert('Starting branchAndBound');
  // Ensure 'numberOfBundles' field exists in data.parts with default value 0
  data.parts.forEach(part => {
    if (typeof part.numberOfBundles !== 'number') {
      part.numberOfBundles = 0;
    }
  });
console.log(data);
  // Define the constraints and objectives
  const constraints = [
    // Constraint: numberOfBundles per SKU cannot be less than 0
    part => part.numberOfBundles >= 0,
    // Constraint: numberOfBundles per SKU cannot exceed 'Bundles Per Truckload'
    part => part.numberOfBundles <= part.bundlesPerTruckload,
    // Constraint: The sum of ("Bundle Size" * 'numberOfBundles') must be equal to data.lcm
    () => data.parts.reduce((sum, part) => sum + part.bundleSize * part.numberOfBundles, 0) === data.lcm,
  ];
console.log(constraints);
  const objective = part => part['Value To Be Used For Optimization'] * part.numberOfBundles;

  const solutions = [];

  // Check if the initial selection satisfies all constraints
  const initialSatisfiesConstraints = constraints.every(constraint => constraint(initialSelection));
  console.log(initialSatisfiesConstraints);
  if (initialSatisfiesConstraints) {
    // If the initial selection satisfies constraints, return it as the solution
    alert('Initial selection works');
    return [{ parts: initialSelection, closenessScore: 0 }];
  }
  //alert('Initial selection does not work');

  // Recursive function to explore and optimize solutions
  function explore(parts, currentSolution, remainingIndices) {
    if (remainingIndices.length === 0) {
      // Check if the current solution satisfies all constraints
      if (constraints.every(constraint => constraint(parts))) {
        solutions.push({ parts: parts, closenessScore: calculateClosenessScore(parts, initial_selection) });
      }
      return;
    }

    const currentIndex = remainingIndices[0];
    const remaining = remainingIndices.slice(1);

    // Explore two possibilities for the current SKU: with and without bundles
    const part = parts[currentIndex];
    const withBundles = [...parts];
    const withoutBundles = [...parts];

    withBundles[currentIndex] = { ...part, numberOfBundles: part['Bundles Per Truckload'] };
    withoutBundles[currentIndex] = { ...part, numberOfBundles: 0 };

    explore(withBundles, currentSolution, remaining);
    explore(withoutBundles, currentSolution, remaining);
  }

  // Start exploration
  const initialIndices = data.parts.map((part, index) => index);
  explore(data.parts, initial_selection, initialIndices);

  // Function to calculate the closeness score for a solution
  function calculateClosenessScore(parts, initialSelection) {
    let closenessScore = 0;
    parts.forEach(part => {
      const initial = initialSelection.find(sel => sel.SKU === part.SKU);
      if (initial) {
        closenessScore += Math.abs(part.numberOfBundles - initial.numberOfBundles);
      }
    });
    return closenessScore;
  }

  // Sort solutions by closeness in ascending order and return the top 5
  solutions.sort((a, b) => a.closenessScore - b.closenessScore);
  return solutions.slice(0, 5);
}

// Example usage
const data = {
  date: '2023-10-18',
  lcm: 60,
  parts: [
    { SKU: 'SKU1', 'bundleSize': 20, 'bundlesPerTruckload': 3, 'orderValue': 10 },
    { SKU: 'SKU2', 'bundleSize': 50, 'bundlesPerTruckload': 2, 'orderValue': 10 },
  ]
};
//console.log(data);

const initialSelection = [
  { SKU: 'SKU1', numberOfBundles: 3},
  { SKU: 'SKU2', numberOfBundles: 0 },
];
//console.log(initialSelection);

// Match SKUs in initialSelection with data.parts and add the missing properties
initialSelection.forEach(selection => {
  const matchingPart = data.parts.find(part => part.SKU === selection.SKU);
  if (matchingPart) {
    selection['bundlesPerTruckload'] = matchingPart['bundlesPerTruckload'];
    selection['bundleSize'] = matchingPart['bundleSize'];
    selection['orderValue'] = matchingPart['orderValue'];
  }
});
//console.log(initialSelection);

// Define the constraints
const constraints = (inputArray) => [
  // Constraint: numberOfBundles per SKU cannot be less than 0
  part => {
    const isSatisfied = part.numberOfBundles >= 0;
    if (!isSatisfied) {
      console.log(`Constraint not satisfied: SKU "${part.SKU}" has numberOfBundles less than 0.`);
    }
    return isSatisfied;
  },
  // Constraint: numberOfBundles per SKU cannot exceed 'bundlesPerTruckload'
  part => {
    const isSatisfied = part.numberOfBundles <= part.bundlesPerTruckload;
    if (!isSatisfied) {
      console.log(`Constraint not satisfied: SKU "${part.SKU}" has numberOfBundles exceeding bundlesPerTruckload.`);
    }
    return isSatisfied;
  },
  // Constraint: The sum of ("bundleSize" * 'numberOfBundles') must be equal to data.lcm
  () => {
    const sum = data.parts.reduce((sum, part) => sum + part.bundleSize * part.numberOfBundles, 0);
    const isSatisfied = sum === data.lcm;
    if (!isSatisfied) {
      console.log(`Constraint not satisfied: Total size does not match data.lcm. Current total size: ${sum}`);
    }
    return isSatisfied;
  },
];
console.log(constraints);

// Function to calculate the closeness score
function calculateClosenessScore(parts, initialSelection) {
  let closenessScore = 0;
  parts.forEach(part => {
    const initial = initialSelection.find(sel => sel.SKU === part.SKU);
    if (initial) {
      closenessScore += Math.abs(part.numberOfBundles - initial.numberOfBundles);
    }
  });
  return closenessScore;
}

const initialSatisfiesConstraints = constraints.every(constraint => constraint(initialSelection));

console.log(initialSatisfiesConstraints);

if (initialSatisfiesConstraints) {
  // If the initial selection satisfies constraints, calculate and display the closeness score
  const closenessScore = calculateClosenessScore(data.parts, initialSelection);
  alert('Closeness Score: ' + closenessScore);
}

//const top5Optimizations = branchAndBound(data, initialSelection);
//console.log(top5Optimizations);

