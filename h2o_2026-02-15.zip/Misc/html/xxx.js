const packingData = {
  date: "2023-10-21_14-33-33",
  lcm: 720,
  parts: [
    {
      SKU: "1CESF40019SH",
      partDescription: "3/4\" PVC PIPE SCH 40",
      sticksPerBundle: 400,
      bundlesPerTruckload: 24,
      bundleSize: 30,
      rank: 2,
    },
  ],
};

const date = packingData.date;
const fullTruckSize = packingData.lcm;
const data = packingData.parts;
let truckSize = fullTruckSize;

function knapsack(items,truckSize) {

  const n = items.length;
  // Create a 2D table to store the maximum values for different subproblems
  const dp = new Array(n + 1).fill(null).map(() => new Array(lcm + 1).fill(0));

  // Build the DP table
  for (let i = 0; i <= n; i++) {
    for (let w = 0; w <= truckSize; w++) {
      if (i === 0 || w === 0) {
        dp[i][w] = 0;
      } else if (items[i - 1].bundleSize <= w) {
        // Check if including the item is beneficial
        dp[i][w] = Math.max(
          dp[i - 1][w],
          dp[i - 1][w - item[i - 1].bundleSize] +
            parts[i - 1].rank * parts[i - 1].sticksPerBundle
        );
      } else {
        dp[i][w] = dp[i - 1][w];
      }
    }
  }

  // Find the selected items and count bundles per SKU
  const selectedItems = [];
  const bundlesPerSKU = {}; // A map to store the number of bundles per SKU

  for (let i = n, w = lcm; i > 0; i--) {
    if (dp[i][w] !== dp[i - 1][w]) {
      const part = parts[i - 1];
      if (!bundlesPerSKU[part.SKU]) {
        bundlesPerSKU[part.SKU] = 0;
      }
      if (bundlesPerSKU[part.SKU] < part.bundlesPerTruckload) {
        selectedItems.push(part);
        w -= part.bundleSize;

        // Increment the bundles count for this SKU
        bundlesPerSKU[part.SKU]++;
      }
    }
  }

  // Ensure at least one bundle per SKU
  for (const part of parts) {
    if (!bundlesPerSKU[part.SKU]) {
      // If no bundles selected for this SKU, select one
      selectedItems.push(part);
      bundlesPerSKU[part.SKU] = 1;
    }
  }

  // Calculate the total selected size
  let totalSelectedSize = 0;
  for (const item of selectedItems) {
    totalSelectedSize += item.bundleSize;
  }

  // Check the constraints
  const isDivisibleBy6 = Object.keys(bundlesPerSKU).every(
    SKU => bundlesPerSKU[SKU] % 6 === 0
  );

  console.log("Best Solution:");
  console.log("Number of Bundles Per SKU in the Optimal Solution:");

  if (isDivisibleBy6 && totalSelectedSize === lcm) {
    console.log("Size constraint met. Total size equals the truck size.");
  } else {
    console.log("Size constraint not met.");
  }

  for (const SKU in bundlesPerSKU) {
    console.log(`${SKU}: ${bundlesPerSKU[SKU]}`);
  }

  return selectedItems;
}

const optimizedSolution = knapsack(packingData);

if (optimizedSolution.length > 0) {
  const totalSize = optimizedSolution.reduce(
    (total, item) => total + item.bundleSize,
    0
  );
  const totalRank = optimizedSolution.reduce(
    (total, item) => total + item.rank * item.sticksPerBundle,
    0
  );
  console.log(`Total Size: ${totalSize}`);
  console.log(`Total Rank: ${totalRank}`);
} else {
  console.log("No feasible solution found");
}

