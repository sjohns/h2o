/*
const packingData = {
    "date": "2023-10-29_17-52-03",
    "lcm": 720,
    "parts": [
        {
            "SKU": "1CESF40013SH",
            "partDescription": "1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 360,
            "bundlesPerTruckload": 36,
            "bundleSize": 20,
            "rank": 5
        },
        {
            "SKU": "1CESF40019SH",
            "partDescription": "3/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 400,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 10
        },
        {
            "SKU": "1CESF40025SH",
            "partDescription": "1\" PVC PIPE SCH 40",
            "sticksPerBundle": 280,
            "bundlesPerTruckload": 20,
            "bundleSize": 36,
            "rank": 10
        },
        {
            "SKU": "1 1/4\" PVC PIPE SCH 40",
            "partDescription": "1 1/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 220,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 10
        },
        {
            "SKU": "1CESF40038SH",
            "partDescription": "1 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 180,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 2
        },
        {
            "SKU": "1CESF40050SH",
            "partDescription": "2\" PVC PIPE SCH 40",
            "sticksPerBundle": 105,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 1
        },
        {
            "SKU": "1CESF40060SH",
            "partDescription": "2 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 73,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 3
        },
        {
            "SKU": "1CESF40075SH",
            "partDescription": "3\" PVC PIPE SCH 40",
            "sticksPerBundle": 75,
            "bundlesPerTruckload": 16,
            "bundleSize": 45,
            "rank": 4
        },
        {
            "SKU": "1CESF40100SH",
            "partDescription": "4\" PVC PIPE SCH 40",
            "sticksPerBundle": 57,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 6
        },
        {
            "SKU": "6\" PVC PIPE SCH 40",
            "partDescription": "6\" PVC PIPE SCH 40",
            "sticksPerBundle": 26,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 7
        },
        {
            "SKU": "8\" PVC PIPE SCH 40",
            "partDescription": "8\" PVC PIPE SCH 40",
            "sticksPerBundle": 15,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 8
        },
        {
            "SKU": "10\" PVC PIPE SCH 40",
            "partDescription": "10\" PVC PIPE SCH 40",
            "sticksPerBundle": 12,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 10
        }
    ]
};

*/
