
const fullTruckSize = packingData.lcm;

const maxTruckSize = fullTruckSize;

const modSize = 6; // Set modSize as a constant variable

const truckFraction = 0.95; // Set truckFraction as a constant variable



function calculateBundleDifference(solution) {
  const sumOfSquares = solution.reduce((sum, item) => {
    return sum + Math.pow(item.numberOfBundles, 2);
  }, 0);
  const average = sumOfSquares / solution.length;
  return average;
}

function findAllSolutions(truckSizeConstraint, bundleConstraints) {
  function findCombinations(skus, solution, totalSize) {
    if (skus.length === 0) {
      if (totalSize >= truckSizeConstraint.minTruckSize && totalSize <= truckSizeConstraint.maxTruckSize) {
        solutions.push([...solution]);
      }
      return;
    }

    const sku = skus[0];
    const constraints = bundleConstraints[sku];
    for (let bundles = Math.max(constraints.minNumberOfBundles, 1); bundles <= constraints.maxNumberOfBundles; bundles++) {
      solution.push({ SKU: sku, numberOfBundles: bundles });
      findCombinations(skus.slice(1), solution, totalSize + bundles * packingData.parts.find(part => part.SKU === sku).bundleSize);
      solution.pop();
    }
  }

  const solutions = [];
  const allSKUs = Object.keys(bundleConstraints);
  findCombinations(allSKUs, [], 0);
  return solutions;
};

function findSolutionWithMinDifference(allPossibleSolutions) {
  let minDifference = Infinity;
  let bestSolution = null;

  for (const solution of allPossibleSolutions) {
    const difference = calculateBundleDifference(solution);
    if (difference < minDifference) {
      minDifference = difference;
      bestSolution = solution;
    }
  }

  return { bestSolution, minDifference };
}
/*
function createPackingDataForm(SKUs) {
    const packingDataForm = document.createElement('form');
    packingDataForm.id = 'select_SKUs';

    const table = document.createElement('table');
    table.border = '1';

    const tableHeader = document.createElement('tr');
    const headers = ['Part Description', 'Select'];

    headers.forEach(headerText => {
        const header = document.createElement('th');
        header.textContent = headerText;
        tableHeader.appendChild(header);
    });

    table.appendChild(tableHeader);

    SKUs.forEach(sku => {
        const row = document.createElement('tr');

        // Part Description
        const partDescriptionCell = document.createElement('td');
        partDescriptionCell.textContent = sku.partDescription;
        row.appendChild(partDescriptionCell);

        // Create a checkbox cell
        const selectCell = document.createElement('td');
        const selectCheckbox = document.createElement('input');
        selectCheckbox.type = 'checkbox';
        selectCheckbox.name = 'selectedSKUs';
        selectCheckbox.value = sku.SKU; // Use SKU as the checkbox value
        selectCell.appendChild(selectCheckbox);
        row.appendChild(selectCell);

        table.appendChild(row);
    });

    packingDataForm.appendChild(table);

    // Add a submit button to submit the form
    const submitButton = document.createElement('input');
    submitButton.type = 'submit';
    submitButton.value = 'Submit';
    packingDataForm.appendChild(submitButton);

    // Add an event listener to the form to handle form submission
    packingDataForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent the default form submission

        // Retrieve selected SKUs here
        const selectedSKUs = Array.from(packingDataForm.querySelectorAll('input[name=selectedSKUs]:checked')).map(checkbox => checkbox.value);

        // Check if at least one SKU is selected
        if (selectedSKUs.length === 0) {
            alert('Please select at least one SKU before submitting.');
        } else {
            console.log('Selected SKUs:', selectedSKUs);
            // You can call your matchData function here with the selected SKUs and the 'parts' array
            matchData(parts, selectedSKUs);

            // Reset the form after submission
            packingDataForm.reset();        }
    });

    document.body.appendChild(packingDataForm);
}

*/

