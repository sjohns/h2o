// Function to create the form and table

function createPackingDataForm(data) 
{
    const packingDataForm = document.createElement('form');
    packingDataForm.id = 'packing_data';

    const table = document.createElement('table');
    table.border = '1';

    // Create the table header
    const tableHeader = document.createElement('tr');
    const SKUHeader = document.createElement('th');
    SKUHeader.textContent = 'SKU';
    const descriptionHeader = document.createElement('th');
    descriptionHeader.textContent = 'Part Description';
    const bundlesHeader = document.createElement('th');
    bundlesHeader.textContent = 'Number of Bundles';
    const sticksPerBundleHeader = document.createElement('th');
    sticksPerBundleHeader.textContent = 'Sticks Per Bundle';
    const totalSticksHeader = document.createElement('th');
    totalSticksHeader.textContent = 'Total Sticks';
    const bundleSizeHeader = document.createElement('th');
    bundleSizeHeader.textContent = 'Bundle Size';
    const totalSizeHeader = document.createElement('th');
    totalSizeHeader.textContent = 'Total Size';
    
    tableHeader.appendChild(SKUHeader);
    tableHeader.appendChild(descriptionHeader);
    tableHeader.appendChild(bundlesHeader);
    tableHeader.appendChild(sticksPerBundleHeader);
    tableHeader.appendChild(totalSticksHeader);
    tableHeader.appendChild(bundleSizeHeader);
    tableHeader.appendChild(totalSizeHeader);
    
    table.appendChild(tableHeader);    

  // Initialize variables for calculations
  let truckLoad = 0;
  let totalRank = 0;

  // Create a row for each SKU
  data.forEach(function() {
    const row = document.createElement('tr');

  // SKU
        const SKUCell = document.createElement('td');
        SKUCell.textContent = SKU;
        row.appendChild(SKUCell);
        
        // Part Description
        const partDescriptionCell = document.createElement('td');
        partDescriptionCell.textContent = partDescription;
        row.appendChild(partDescriptionCell);
        
        // Number of Bundles Input
        const bundlesInput = document.createElement('input');
        bundlesInput.type = 'number';
        bundlesInput.name = 'numberOfBundles';
        bundlesInput.value = 0;
        bundlesInput.min = 0;
        bundlesInput.max = 'bundlesPerTruckload';
        bundlesInput.step = 1;
        row.appendChild(bundlesInput);
        
                // Sticks Per Bundle Field
        const sticksPerBundleCell = document.createElement('td');
        sticksPerBundleCell.textContent = 'sticksPerBundle';
        row.appendChild(sticksPerBundleCell); 
        
        // Total Sticks Field (Calculated)
        const totalSticksCell = document.createElement('td');
        const totalSticksInput = document.createElement('input');
        totalSticksInput.type = 'text';
        totalSticksInput.name = 'totalSticks';
        totalSticksInput.value = 0;
        totalSticksInput.readOnly = true;
        row.appendChild(totalSticksCell);
        totalSticksCell.appendChild(totalSticksInput);
        
               // Bundle Size
        const bundleSizeCell = document.createElement('td');
        bundleSizeCell.textContent = bundleSize;
        row.appendChild(bundleSizeCell);

        // Total Sizes Field (Calculated)
        const totalSizeCell = document.createElement('td');
        const totalSizeInput = document.createElement('input');
        totalSizeInput.type = 'text';
        totalSizeInput.name = 'totalSize[]';
        totalSizeInput.value = 0;
        totalSizeInput.readOnly = true;
        row.appendChild(totalSizeCell);
        totalSizeCell.appendChild(totalSizeInput);

    // Calculate 'Total Sticks' and 'Total Size' on input change
    bundlesInput.addEventListener('input', () => {
      const calculatedTotalSticks = bundlesInput.value * sticksPerBundle;
      totalSticksInput.value = calculatedTotalSticks;
      const calculatedTotalSize = bundlesInput.value * bundleSize;
      totalSizeInput.value = calculatedTotalSize;

    });

 table.appendChild(row);  
    packingDataForm.appendChild(table);
    document.body.appendChild(packingDataForm);
    

    });
    

};

createPackingDataForm(data); 

