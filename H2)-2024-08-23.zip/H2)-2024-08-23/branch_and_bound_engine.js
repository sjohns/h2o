/**
 * BranchAndBoundEngine class:
 * - This class implements a Branch and Bound algorithm to find optimal combinations of SKUs that fit within a given truck size while adhering to various constraints.
 * 
 * Overview:
 * The `BranchAndBoundEngine` class is designed to determine the best way to load a truck with bundles of SKUs (Stock Keeping Units) based on predefined constraints. 
 * The class uses the Branch and Bound method, a popular algorithm in combinatorial optimization, to explore all possible combinations of SKUs and select the optimal one.
 * 
 * Branch and Bound Method:
 * The Branch and Bound algorithm is a tree-based search method that is used to solve optimization problems. It systematically explores branches of a decision tree, 
 * pruning branches that do not lead to optimal solutions, thus reducing the number of potential solutions that need to be evaluated. This makes the algorithm 
 * particularly effective for problems like load optimization, where there are numerous possible combinations to consider.
 * 
 * Description:
 * - The `BranchAndBoundEngine` class takes in a set of SKUs, each with specific constraints, and attempts to find the best combination of SKUs that fit within 
 *   the truck's capacity.
 * - The class is designed to be compatible with older browsers, so it uses older JavaScript syntax (e.g., `var` instead of `const` and `let`).
 * - Only two methods, `bestSolution` and `updateAll`, are intended to be called from outside the class. The rest of the methods are internal and marked with 
 *   an underscore (`_`) to indicate that they are private.
 * - The class uses a flag (`initialCalculation`) to handle the scenario where no valid solution is found initially. This flag is set to `true` during the first calculation 
 *   and ensures that the system reverts to the initial bundle constraints if no solution is found, but only after the first attempt. If no valid solution is found 
 *   after the initial calculation, the flag is set to `false` and the system reverts to the last valid solution instead.
 * - An important consideration is the scenario where no valid solution is found. In this case, the class will revert to the last valid solution and display an 
 *   alert. It is expected that the user interface (UI) will handle this scenario appropriately, as the alert alone may not be sufficient.
 * 
 * Example Usage:
 * 
 * const skus = {
 *     sku1: { skuId: 'sku1', SKU: 'Pipe A', sticksPerBundle: 10, popularityScore: 5 },
 *     sku2: { skuId: 'sku2', SKU: 'Pipe B', sticksPerBundle: 20, popularityScore: 3 },
 * };
 * 
 * const engine = new BranchAndBoundEngine(skus, 1000, new RatiosCalculator());
 * const bestSolution = engine.bestSolution();
 * 
 * Output:
 * - The best combination of SKUs that fits within the truck's capacity.
 * 
 * Remaining Problem:
 * - A known issue arises if no initial solution is found during the first calculation. Although the flag helps manage this by reverting to initial constraints, 
 *   the system might still struggle to find a valid solution in certain edge cases. Further refinement may be necessary to address these scenarios.
 * 
 * Date: 2024-07-11
 * Author: Stephen Johns
 */

// [Following this, the rest of the code and methods would remain unchanged, except for commenting out the console logs.]

class BranchAndBoundEngine {
    constructor(SKUs, lcmValue, ratiosCalculator) {
        // Initialize properties for SKUs, constraints, and solution tracking
        this.SKUs = SKUs;
        this.previousSolutions = [];
        this.fullTruckSize = lcmValue;
        this.minTruckSize = 1;
        this.MOD_SIZE = 6;
        this.minFractionWhereSKUsNotDivisiable = 0.95;
        this.maxFractionWhereSKUsNotDivisiable = 0.98;
        this.bundleConstraints = {};
        this.initialBundleConstraints = {};
        this.lastBundleConstraints = {};
        this.truckSizeConstraints = {};
        this.ratiosCalculator = ratiosCalculator;
        this.solutions = [];
        this.currentMaxTruckSize = 0;
        this.initialCalculation = true;  // Flag to manage the initial calculation state
        this.solution = [];

        // Initialize constraints based on the SKUs provided
        this._initializeConstraints();
    }

    _initializeConstraints() {
        // Set truck size constraints and bundle constraints based on SKUs
        // console.log('fulltruckSize :', this.fullTruckSize);
        
        if (Object.keys(this.SKUs).length === 1) {
            const singleSKU = Object.values(this.SKUs)[0];
            this.truckSizeConstraints = { minTruckSize: this.fullTruckSize, maxTruckSize: this.fullTruckSize };
            // console.log('1 SKU');
            // console.log('truckSizeConstraints:', this.truckSizeConstraints);
        } else {
            const allSKUsHaveDivisibleBundles = Object.values(this.SKUs).every(sku => {
                const calculatedBundlesPerTruckload = parseInt(sku.calculatedBundlesPerTruckload, 10);
                // console.log('calculatedBundlesPerTruckload:', calculatedBundlesPerTruckload);
                // console.log(sku.calculatedBundlesPerTruckload / this.MOD_SIZE);
                const isDivisible = calculatedBundlesPerTruckload % this.MOD_SIZE === 0;
                // console.log(`isDivisible: ${isDivisible}`);
                return isDivisible;
            });

            // console.log('allSKUsHaveDivisibleBundles: ', allSKUsHaveDivisibleBundles);

            if (allSKUsHaveDivisibleBundles) {
                this.truckSizeConstraints = { minTruckSize: this.fullTruckSize, maxTruckSize: this.fullTruckSize };
                // console.log('SKU by 6');
                // console.log('truckSizeConstraints :', this.truckSizeConstraints);
            } else {
                this._setTruckSizeConstraints(this.minFractionWhereSKUsNotDivisiable, this.maxFractionWhereSKUsNotDivisiable);
                // console.log('SKU not by 6');
                // console.log('truckSizeConstraints :', this.truckSizeConstraints);
            }
        }

        try {
            Object.values(this.SKUs).forEach(sku => {
                this.bundleConstraints[sku.skuId] = {
                    minNumberOfBundles: 1,
                    maxNumberOfBundles: sku.calculatedBundlesPerTruckload
                };
            });

            this.initialBundleConstraints = this._deepClone(this.bundleConstraints);
            this.lastBundleConstraints = this._deepClone(this.bundleConstraints);
        } catch (error) {
            this._handleError('Error calculating bundle constraints', error);
        }
        // console.log('initialBundleConstraints :', this.initialBundleConstraints);
        // console.log('lastBundleConstraints :', this.lastBundleConstraints);
        // console.log('bundleConstraints :', this.bundleConstraints);
    }
    
    _setTruckSizeConstraints(minFraction, maxFraction) {
        // Set the minimum and maximum truck size constraints based on the fractions provided
        const minTruckSize = Math.floor(this.fullTruckSize * minFraction);
        const maxTruckSize = Math.floor(this.fullTruckSize * maxFraction);
        this.truckSizeConstraints = { minTruckSize, maxTruckSize };
    }

    _checkBundlesPerSKUConstraints(solution) {
        // Validate that the number of bundles per SKU in the solution meets the constraints
        try {
            const SKUBundles = this._countBundlesPerSKU(solution);

            for (const [skuId, count] of Object.entries(SKUBundles)) {
                const constraints = this.bundleConstraints[skuId];
                if (count < constraints.minNumberOfBundles || count > constraints.maxNumberOfBundles) {
                    return false;
                }
            }

            return true;
        } catch (error) {
            this._handleError('Error checking number of bundles per size', error);
        }
    }

    _countBundlesPerSKU(solution) {
        // Count the number of bundles per SKU in the given solution
        const sizeBundlesCount = {};
        solution.forEach(item => {
            const sku = this.SKUs[item.skuId];
            if (!sizeBundlesCount[sku.skuId]) {
                sizeBundlesCount[sku.skuId] = 0;
            }
            sizeBundlesCount[sku.skuId] += item.numberOfBundles;

            this._validateBundleConstraints(item);
        });
        return sizeBundlesCount;
    }

    _validateBundleConstraints(item) {
        // Ensure the number of bundles for an SKU in the solution is within its defined constraints
        const bundleConstraints = this.bundleConstraints[item.skuId];
        if (item.numberOfBundles < bundleConstraints.minNumberOfBundles || item.numberOfBundles > bundleConstraints.maxNumberOfBundles) {
            throw new Error(`Number of bundles for skuId ${item.skuId} is out of bounds.`);
        }
    }

    _findAllSolutions() {
        // Generate all possible valid solutions based on the SKU constraints
        try {
            this.solutions = [];
            this.currentMaxTruckSize = 0;
            const allSKUs = Object.keys(this.bundleConstraints);
            this._findSKUCombinations(allSKUs, [], 0);
            this.solutions = this.solutions.filter(solution => solution.totalSize >= this.currentMaxTruckSize);

            if (this.solutions.length < 1) {
                if (!this.initialCalculation) {
                    this.bundleConstraints = this._deepClone(this.lastBundleConstraints);
                    alert('No possible solutions for last modification. The last modification has been reversed.');
                    this.bestSolution();
                    return;
                }
            }

            return this.solutions;
        } catch (error) {
            this._handleError('Error finding all solutions', error);
        }
    }

    _findSKUCombinations(SKUs, solution, totalSize) {
        // Recursively explore different combinations of SKUs to find valid solutions
        if (SKUs.length === 0) {
            if (totalSize < this.currentMaxTruckSize) {
                return;
            }
            this.currentMaxTruckSize = totalSize;
            if (this._isValidSolution(solution, totalSize)) {
                this.solutions.push({ solution: [...solution], totalSize });
            }
            this.solutions = this.solutions.filter(sol => sol.totalSize >= this.currentMaxTruckSize);

            return;
        }

        const [skuId, ...remainingSKUs] = SKUs;
        const constraints = this.bundleConstraints[skuId];
        const skuInfo = this.SKUs[skuId];

        for (let numberOfBundles = constraints.minNumberOfBundles; numberOfBundles <= constraints.maxNumberOfBundles; numberOfBundles++) {
            const newSize = totalSize + numberOfBundles * skuInfo.calculatedBundleSize;

            if (newSize > this.truckSizeConstraints.maxTruckSize) break;

            solution.push({ skuId, numberOfBundles });
            this._findSKUCombinations(remainingSKUs, solution, newSize);
            solution.pop();
        }
    }

    calculateTruckSize(solution) {
        // Calculate the total truck size for a given solution
        return solution.reduce((totalTruckSize, item) => {
            const skuData = this.SKUs[item.skuId];
            if (skuData === undefined) {
                console.error(`Undefined SKU data for skuId: ${item.skuId}`);
                return totalTruckSize;
            }
            const skuSize = skuData.calculatedBundleSize;
            return totalTruckSize + (skuSize * item.numberOfBundles);
        }, 0);
    }

    _isValidSolution(solution, totalSize) {
        // Check if the solution meets all constraints, including truck size and bundle counts
        return this._checkBundlesPerSKUConstraints(solution) &&
            totalSize >= this.truckSizeConstraints.minTruckSize &&
            totalSize <= this.truckSizeConstraints.maxTruckSize;
    }

    bestSolution() {
        // Public method to find the best solution based on the constraints
        this._findAllSolutions();
        // console.log('solutions: ',this.solutions);
        const optimalSolutions = this._findOptimalSolution();
        const optimalSolution = optimalSolutions.solution;
        // console.log('optimalSolution: ',optimalSolution);
        this.lastBundleConstraints = this._deepClone(this.bundleConstraints);
        // console.log('initialCalculation: ',this.initialCalculation);
        this.initialCalculation = false;  // Reset the flag after the first calculation
        // console.log('initialCalculation: ',this.initialCalculation);
        this.solution = optimalSolution;
        return optimalSolution;
    }
  
    _deepClone(obj) {
        // Utility method to create a deep clone of an object
        return JSON.parse(JSON.stringify(obj));
    }

    _handleError(message, error) {
        // Handle errors consistently across the class
        console.error(message, error);
        throw new Error(message);
    }

    _updateCorrectAmount(skuId) {
        // Find the current solution for the given SKU ID
        const solutionForSku = this.solution.find(solution => solution.skuId === skuId);

        if (!solutionForSku) {
            console.error(`No solution found for SKU: ${skuId}`);
            return;
        }

        const numberOfBundles = solutionForSku.numberOfBundles;

        const correctAmountCheckbox = document.querySelector(`#orderTableDataCorrectAmountId${skuId}`);
        if (!correctAmountCheckbox) {
            console.error(`Checkbox not found for SKU: ${skuId}`);
            return;
        }

        if (correctAmountCheckbox.checked) {
            this.bundleConstraints[skuId].minNumberOfBundles = numberOfBundles;
            this.bundleConstraints[skuId].maxNumberOfBundles = numberOfBundles;
        } else {
            this.bundleConstraints[skuId].minNumberOfBundles = this.initialBundleConstraints[skuId].minNumberOfBundles;
            this.bundleConstraints[skuId].maxNumberOfBundles = this.initialBundleConstraints[skuId].maxNumberOfBundles;
        }
     
        this.lastBundleConstraints = this._deepClone(this.bundleConstraints);
        // console.log(`Constraints updated for SKU: ${skuId}`);
        // console.log('corret/not correct initialBundleConstraints:', this.initialBundleConstraints);
        // console.log('corret/not correct lastBundleConstraints:', this.lastBundleConstraints);
        // console.log('corret/not correct bundleConstraints:', this.bundleConstraints);
    }

    _updateConstraints(skuId, action, numberOfBundles) {
        // Ensure numberOfBundles is a valid number
        numberOfBundles = parseInt(numberOfBundles, 10);
        if (isNaN(numberOfBundles)) {
            console.error(`Invalid number of bundles for SKU: ${skuId}`);
            return;
        }
    
        // Update the constraints for a specific SKU based on user actions
        const minNumberOfBundlesInitial = this.initialBundleConstraints[skuId].minNumberOfBundles;
        const maxNumberOfBundlesInitial = this.initialBundleConstraints[skuId].maxNumberOfBundles;
        const minNumberOfBundlesLast = this.lastBundleConstraints[skuId].minNumberOfBundles;
        const maxNumberOfBundlesLast = this.lastBundleConstraints[skuId].maxNumberOfBundles;

        // console.log('skuId: ', skuId);
        // console.log('action: ', action);

        switch (action) {
            case 'increase':
                if (numberOfBundles < maxNumberOfBundlesInitial) {
                    const newNumberOfBundles = Math.max(0, parseInt(numberOfBundles) + 1);
                    this.bundleConstraints[skuId].minNumberOfBundles = newNumberOfBundles;
                    this.bundleConstraints[skuId].maxNumberOfBundles = maxNumberOfBundlesInitial;
                }
                // console.log('after updateAll initialBundleConstraints:', this.initialBundleConstraints);
                // console.log('after updateAll lastBundleConstraints:', this.lastBundleConstraints);
                // console.log('after updateAll bundleConstraints:', this.bundleConstraints);
                break;

            case 'decrease':
                if (numberOfBundles > minNumberOfBundlesInitial) {
                    const newNumberOfBundles = Math.max(0, parseInt(numberOfBundles) - 1);
                    // console.log('newNumberOfBundles: ', newNumberOfBundles);
                    this.bundleConstraints[skuId].maxNumberOfBundles = newNumberOfBundles;
                    this.bundleConstraints[skuId].minNumberOfBundles = minNumberOfBundlesInitial;
                }
                // console.log('after updateAll decrease initialBundleConstraints:', this.initialBundleConstraints);
                // console.log('after updateAll decrease lastBundleConstraints:', this.lastBundleConstraints);
                // console.log('after updateAll decrease bundleConstraints:', this.bundleConstraints);
                break;

            default:
                throw new Error(`Unknown action: ${action}`);
        }
    
        Object.keys(this.bundleConstraints).forEach(otherSkuId => {
            if (otherSkuId !== skuId) {
                const correctAmountCheckbox = document.querySelector(`#orderTableDataCorrectAmountId${otherSkuId}`);
                if (!correctAmountCheckbox || !correctAmountCheckbox.checked) {
                    // If the SKU is not frozen, reset its constraints to the initial values
                    this.bundleConstraints[otherSkuId] = this._deepClone(this.initialBundleConstraints[otherSkuId]);
                }
            }
        });
    }

    _updateButtonStates() {
        // Update the state of UI buttons based on the current constraints and SKU states
        Object.keys(this.SKUs).forEach(skuId => {
            const correctAmountCheckbox = document.querySelector(`#orderTableDataCorrectAmountId${skuId}`);
        
            if (correctAmountCheckbox && correctAmountCheckbox.checked) {
                return; // Skip if checkbox is checked
            }
        
            const row = document.querySelector(`#orderTableDataRowId${skuId}`);
            if (!row) {
                console.error(`Row not found for SKU: ${skuId}`);
                return;
            }

            const numberOfBundles = parseInt(row.getAttribute('data-total-bundles'), 10);

            const minNumberOfBundles = this.initialBundleConstraints[skuId]?.minNumberOfBundles;
            const maxNumberOfBundles = this.initialBundleConstraints[skuId]?.maxNumberOfBundles;

            if (isNaN(numberOfBundles) || minNumberOfBundles === undefined || maxNumberOfBundles === undefined) {
                console.error(`Invalid data for SKU: ${skuId}`);
                return;
            }

            const increaseButton = document.querySelector(`#orderTableDataIncreaseAmountId${skuId}`);
            const decreaseButton = document.querySelector(`#orderTableDataDecreaseAmountId${skuId}`);

            if (increaseButton) {
                increaseButton.disabled = numberOfBundles >= maxNumberOfBundles;
            }
        
            if (decreaseButton) {
                decreaseButton.disabled = numberOfBundles <= minNumberOfBundles;
            }
        });
    }

    updateAll(skuId, action, bundles) {
        // Update all constraints, recalculate the best solution, and update the UI
        bundles = parseInt(bundles, 10); // Convert to integer, base 10
        if (isNaN(bundles)) {
            console.error(`Invalid number of bundles for SKU: ${skuId}`);
            return;
        }

        // Update the constraints based on the action
        this._updateConstraints(skuId, action, bundles); 

        // Recalculate the best solution
        const bestSolution = this.bestSolution();

        if (bestSolution) {
            // If a valid solution is found, clone the current bundle constraints to lastBundleConstraints
            this.lastBundleConstraints = this._deepClone(this.bundleConstraints);
        
            // Assuming `orderTable` is a global or properly scoped variable
            orderTable = new OrderTable(this.SKUs, bestSolution, this); // Recreate the OrderTable with the new solution

            // Update the button states after updating the constraints
            this._updateButtonStates();

            // console.log('Cloned bundleConstraints to lastBundleConstraints after a valid solution was found.');
        } else {
            console.error('No valid solution found. Constraints were not cloned.');
        }

        // Optional: Uncomment for debugging
        // console.log('bundleConstraints:', this.bundleConstraints);
    }

    _findOptimalSolution() { 
        // Find the optimal solution from the generated solutions
        // console.log('_findAOptimaSolution - Solutions: ', this.solutions);
    
        if (this.solutions.length === 0) {
            throw new Error("No solutions available");
        } 

        if (this.solutions.length === 1) {
            // console.log('1 solution: ', this.solutions[0]);
            return this.solutions[0];
        }
                
        let minDifference = Infinity;

        this.solutions.forEach(solution => {
            const { differenceSum, totalSticks } = this.ratiosCalculator.popularityScoreDifference(solution);

            solution.differenceSum = differenceSum;
            solution.totalSticks = totalSticks;

            // console.log('solution.differenceSum: ', solution.differenceSum);
            
            if (solution.differenceSum < minDifference) {
                minDifference = solution.differenceSum;
            }
        });
        
        // console.log('minDifference: ', minDifference);
        this.solutions = this.solutions.filter(solution => solution.differenceSum === minDifference);

        if (this.solutions.length === 1) {
            this.lastBestSolution = this.solutions[0];
            return this.solutions[0];
        }
      
        let maxTotalSticks = -Infinity;
      
        this.solutions.forEach(solution => {
            if (solution.totalSticks > maxTotalSticks) {
                maxTotalSticks = solution.totalSticks;
            }
        });
        
        this.solutions = this.solutions.filter(solution => solution.totalSticks === maxTotalSticks);           
        // console.log('end solutions: ', this.solutions);

        if (this.solutions.length === 0) {
            throw new Error("No solutions available");
        } 

        return this.solutions[0];
    }
}
