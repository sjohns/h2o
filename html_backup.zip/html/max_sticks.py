# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

packingData = {
    "date": "2023-10-21_14-33-33",
    "lcm": 720,
    "parts": [
        {
            "SKU": "1CESF40013SH",
            "partDescription": "1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 360,
            "bundlesPerTruckload": 36,
            "bundleSize": 20,
            "rank": 1
        },
        {
            "SKU": "1CESF40019SH",
            "partDescription": "3/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 400,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 2
        },
        {
            "SKU": "1CESF40025SH",
            "partDescription": "1\" PVC PIPE SCH 40",
            "sticksPerBundle": 280,
            "bundlesPerTruckload": 20,
            "bundleSize": 36,
            "rank": 3
        },
        {
            "SKU": "1 1/4\" PVC PIPE SCH 40",
            "partDescription": "1 1/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 220,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 4
        },
        {
            "SKU": "1CESF40038SH",
            "partDescription": "1 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 180,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 5
        },
        {
            "SKU": "1CESF40050SH",
            "partDescription": "2\" PVC PIPE SCH 40",
            "sticksPerBundle": 105,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 6
        },
        {
            "SKU": "1CESF40060SH",
            "partDescription": "2 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 73,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 7
        },
        {
            "SKU": "1CESF40075SH",
            "partDescription": "3\" PVC PIPE SCH 40",
            "sticksPerBundle": 75,
            "bundlesPerTruckload": 16,
            "bundleSize": 45,
            "rank": 8
        },
        {
            "SKU": "1CESF40100SH",
            "partDescription": "4\" PVC PIPE SCH 40",
            "sticksPerBundle": 57,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 9
        },
        {
            "SKU": "6\" PVC PIPE SCH 40",
            "partDescription": "6\" PVC PIPE SCH 40",
            "sticksPerBundle": 26,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 10
        },
        {
            "SKU": "8\" PVC PIPE SCH 40",
            "partDescription": "8\" PVC PIPE SCH 40",
            "sticksPerBundle": 15,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 11
        },
        {
            "SKU": "10\" PVC PIPE SCH 40",
            "partDescription": "10\" PVC PIPE SCH 40",
            "sticksPerBundle": 12,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 12
        },
    ],
}
#print(packingData)


truckSize = packingData['lcm']

data =  packingData['parts']

skuDict = {}
for part in data:
        sku = part['SKU']
        skuDict[sku] = {k: v for k, v in part.items() if k != 'SKU'}

skus = list(skuDict)

def sort_key(sku):
    rank = skuDict[sku]['rank']
    part_description = skuDict[sku]['partDescription']
    return (rank, part_description)

skus = sorted(skuDict.keys(), key=sort_key)

initialSolution = {}
for sku in skus:
    initialSolution[sku] = 1

solution = initialSolution

# Check if all of the bundlesPerTruckload values are divisible by 6.
allDivisibleBy_6 = True
for sku in skus:
    if skuDict[sku]['bundlesPerTruckload'] % 6 != 0:
        allDivisibleBy_6 = False
        break

def branch_and_bound(truckSize, skus, skuDict, solution, iteration_count=0,allDivisibleBy_6=False):

    # Calculate the total size of the solution.
    totalSize = 0
    for sku in skus:
        totalSize += solution[sku] * skuDict[sku]['bundleSize']

    # If the total size is equal to the truck size, return the solution.
    if totalSize == truckSize:
        return solution

    # If the total size is greater than the truck size, return None.
    if totalSize > truckSize:
        return None


    # Calculate the number of sticks for each solution.
    numSticksPerSku = {}
    for sku in skus:
        numSticksPerSku[sku] = solution[sku] * skuDict[sku]['sticksPerBundle']

    # Calculate the total number of sticks.
    totalNumSticks = 0
    for sku in skus:
        totalNumSticks += numSticksPerSku[sku]

    # Calculate the average number of sticks.
    avgNumSticks = totalNumSticks / len(skus)

    # Calculate the difference between the actual number of sticks for each SKU and the average number of sticks.
    diffNumSticks = {}
    for sku in skus:
        diffNumSticks[sku] = numSticksPerSku[sku] - avgNumSticks

    # Sort the SKUs by the difference in the number of sticks.
    skus = sorted(skus, key=lambda sku: abs(numSticksPerSku[sku] - avgNumSticks))

    # If all of the bundlesPerTruckload values are divisible by 6, then a solution is reached when totalSize is equal to truckSize.
    if ~allDivisibleBy_6:
        if totalSize >= 0.95 * truckSize:
            return solution

    # Increment the iteration count.
    iteration_count += 1

    # If the iteration count has reached 200, stop the recursion and return None.
    if iteration_count >= 200:
        return None

    # Create a stack to store the child nodes.
    stack = []

    # Iterate over the SKUs, adding child nodes to the stack.
    for sku in skus:
        child_node = solution.copy()
        child_node[sku] += 1

        # Add the child node to the stack.
        stack.append((skuDict[sku]['rank'], child_node))

    # Recursively solve the child nodes.
    while stack:
        sku, child_node = stack.pop()

        # Solve the child node.
        solution = branch_and_bound(truckSize, skus, skuDict, child_node, iteration_count,allDivisibleBy_6)

        # If a solution was found, return it.
        if solution is not None:
            return solution, totalSize, truckSize

    # No solution was found.
    return None


# Solve the branch and bound problem.
solution, totalSize, truckSize = branch_and_bound(truckSize, skus, skuDict, solution)

def adjust_solution(solution, sku, num_bundles):
  """Adjusts the solution dictionary by adding or subtracting the number of bundles for a given SKU.

  Args:
    solution: A dictionary mapping SKUs to the number of bundles.
    sku: The SKU to adjust.
    num_bundles: The number of bundles to add or subtract.

  Returns:
    A new solution dictionary with the adjusted number of bundles for the given SKU.
  """

  new_solution = solution.copy()
  new_solution[sku] += num_bundles
  return new_solution
