

const packingData = {
    "date": "2023-10-29_17-52-03",
    "lcm": 720,
    "parts": [
        {
            "SKU": "1CESF40013SH",
            "partDescription": "1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 360,
            "bundlesPerTruckload": 36,
            "bundleSize": 20,
            "rank": 5
        },
        {
            "SKU": "1CESF40019SH",
            "partDescription": "3/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 400,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 10
        },
        {
            "SKU": "1CESF40025SH",
            "partDescription": "1\" PVC PIPE SCH 40",
            "sticksPerBundle": 280,
            "bundlesPerTruckload": 20,
            "bundleSize": 36,
            "rank": 10
        },
        {
            "SKU": "1 1/4\" PVC PIPE SCH 40",
            "partDescription": "1 1/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 220,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 10
        },
        {
            "SKU": "1CESF40038SH",
            "partDescription": "1 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 180,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 2
        },
        {
            "SKU": "1CESF40050SH",
            "partDescription": "2\" PVC PIPE SCH 40",
            "sticksPerBundle": 105,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 1
        },
        {
            "SKU": "1CESF40060SH",
            "partDescription": "2 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 73,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 3
        },
        {
            "SKU": "1CESF40075SH",
            "partDescription": "3\" PVC PIPE SCH 40",
            "sticksPerBundle": 75,
            "bundlesPerTruckload": 16,
            "bundleSize": 45,
            "rank": 4
        },
        {
            "SKU": "1CESF40100SH",
            "partDescription": "4\" PVC PIPE SCH 40",
            "sticksPerBundle": 57,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 6
        },
        {
            "SKU": "6\" PVC PIPE SCH 40",
            "partDescription": "6\" PVC PIPE SCH 40",
            "sticksPerBundle": 26,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 7
        },
        {
            "SKU": "8\" PVC PIPE SCH 40",
            "partDescription": "8\" PVC PIPE SCH 40",
            "sticksPerBundle": 15,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 8
        },
        {
            "SKU": "10\" PVC PIPE SCH 40",
            "partDescription": "10\" PVC PIPE SCH 40",
            "sticksPerBundle": 12,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 10
        }
    ]
};

const fullTruckSize = packingData.lcm;

const maxTruckSize = fullTruckSize;

const modSize = 6; // Set modSize as a constant variable

const truckFraction = 0.95; // Set truckFraction as a constant variable

// Add this part to calculate the best solution based on constraints
let truckSizeConstraint = {
  minTruckSize: 0,
  maxTruckSize: fullTruckSize, // You can adjust the max truck size as needed
};

const bundleConstraints = {}; // Add your bundle constraints here

// Function to create constraints based on selected SKUs
function createConstraints(selectedSKUs, allParts, existingConstraints) {
    selectedSKUs.forEach(selectedSKU => {
        const matchingPart = allParts.find(part => part.SKU === selectedSKU);
        if (matchingPart) {
            existingConstraints[selectedSKU] = {
                minNumberOfBundles: 1,
                maxNumberOfBundles: matchingPart.bundlesPerTruckload
            };
        }
    });
}

// Function to extract data based on selected SKUs
function extractData(selectedSKUs, allParts) {
    const data = selectedSKUs.map(selectedSKU => {
        const matchingPart = allParts.find(part => part.SKU === selectedSKU);
        return matchingPart ? { ...matchingPart } : null;
    }).filter(data => data !== null);
    return data;
}

// Function to calculate the average bundle difference
function calculateBundleDifference(solution) {
  const sumOfSquares = solution.reduce((sum, item) => {
    return sum + Math.pow(item.numberOfBundles, 2);
  }, 0);
  const average = sumOfSquares / solution.length;
  return average;
}

// Function to find all possible solutions based on constraints
function findAllSolutions(truckSizeConstraint, bundleConstraints) {
  function findCombinations(skus, solution, totalSize) {
    if (skus.length === 0) {
      if (totalSize >= truckSizeConstraint.minTruckSize && totalSize <= truckSizeConstraint.maxTruckSize) {
        solutions.push([...solution]);
      }
      return;
    }

    const sku = skus[0];
    const constraints = bundleConstraints[sku];
    for (let bundles = Math.max(constraints.minNumberOfBundles, 1); bundles <= constraints.maxNumberOfBundles; bundles++) {
      solution.push({ SKU: sku, numberOfBundles: bundles });
      findCombinations(skus.slice(1), solution, totalSize + bundles * packingData.parts.find(part => part.SKU === sku).bundleSize);
      solution.pop();
    }
  }

  const solutions = [];
  const allSKUs = Object.keys(bundleConstraints);
  findCombinations(allSKUs, [], 0);
  return solutions;
}

// Function to find the solution with the minimum bundle difference
function findSolutionWithMinDifference(allPossibleSolutions) {
  let minDifference = Infinity;
  let bestSolution = null;

  for (const solution of allPossibleSolutions) {
    const difference = calculateBundleDifference(solution);
    if (difference < minDifference) {
      minDifference = difference;
      bestSolution = solution;
    }
  }

  return { bestSolution, minDifference };
}

function createOrderForm() {
  // First, create the HTML form
  const form = $('<form>', { id: 'createOrder' });

  // Iterate through packingData.parts to create form fields
  packingData.parts.forEach(part => {
    // Create a container div for each part
    const partDiv = $('<div>');

    // Create a hidden input for SKU
    const skuInput = $('<input>', { type: 'hidden', name: 'SKU', value: part.SKU });

    // Create a hidden input for numberOfBundles with a default value of 1
    const numBundlesInput = $('<input>', { type: 'hidden', name: 'numberOfBundles', value: 1 });

    // Create a description field
    const descInput = $('<input>', { type: 'text', name: 'description', value: part.partDescription });

    // Create the "Keep" checkbox
    const keepCheckbox = $('<input>', { type: 'checkbox', name: 'Keep' });

    // Create the "Increase" button
    const increaseButton = $('<button>', { type: 'button', text: 'Increase' });

    // Create the "Decrease" button
    const decreaseButton = $('<button>', { type: 'button', text: 'Decrease' });

    // Append the form elements to the partDiv
    partDiv.append(skuInput, numBundlesInput, descInput, keepCheckbox, increaseButton, decreaseButton);

    // Append the partDiv to the form
    form.append(partDiv);
  });

  // Create a submit button
  const submitButton = $('<input>', { type: 'submit', value: 'Create Order' });

  // Append the submit button to the form
  form.append(submitButton);

  // Append the form to the document body
  $('body').append(form);

  // Add event handling for "Keep," "Increase," and "Decrease" buttons
  $('.createOrder').on('change', 'input[name="Keep"]', function() {
    // Disable or enable the associated "Increase" and "Decrease" buttons based on "Keep" checkbox
    const increaseButton = $(this).parent().find('button:contains("Increase")');
    const decreaseButton = $(this).parent().find('button:contains("Decrease")');
    if ($(this).is(':checked')) {
      increaseButton.prop('disabled', true);
      decreaseButton.prop('disabled', true);
    } else {
      increaseButton.prop('disabled', false);
      decreaseButton.prop('disabled', false);
    }
  });

  $('.createOrder').on('click', 'button:contains("Increase"), button:contains("Decrease")', function() {
    // When "Increase" or "Decrease" button is clicked, populate the "action" hidden field and call the calculateOrder function
    const hiddenActionField = $(this).parent().find('input[name="action"]');
    hiddenActionField.val($(this).text());
    calculateOrder();
  });

  // Function to create constraints and extract data based on selected SKUs
  function calculateOrder() {
    const selectedSKUs = [];
    const allParts = packingData.parts;
    
    // Get selected SKUs
    $('input[name="SKU"]').each(function() {
      if ($(this).parent().find('input[name="Keep"]').is(':checked')) {
        selectedSKUs.push($(this).val());
      }
    });

    // Create constraints
    const existingConstraints = {};
    createConstraints(selectedSKUs, allParts, existingConstraints);

    // Extract data
    const selectedData = extractData(selectedSKUs, allParts);

    // Here you can perform further calculations or actions based on selected data
    // For now, let's log the results to the console
    console.log('Selected SKUs:', selectedSKUs);
    console.log('Constraints:', existingConstraints);
    console.log('Selected Data:', selectedData);
  }
}

// Call the createOrderForm function to generate the form
createOrderForm();
    
const allPossibleSolutions = findAllSolutions(truckSizeConstraint, bundleConstraints);
const { bestSolution, minDifference } = findSolutionWithMinDifference(allPossibleSolutions);


    // Create the "Keep" checkbox
    const keepCheckbox = $('<input>', { type: 'checkbox', name: 'Keep' });

    // Create the "Increase" button
    const increaseButton = $('<button>', { type: 'button', text: 'Increase' });

    // Create the "Decrease" button
    const decreaseButton = $('<button>', { type: 'button', text: 'Decrease' });

    // Append the form elements to the partDiv
    partDiv.append(skuInput, numBundlesInput, descInput, keepCheckbox, increaseButton, decreaseButton);

    // Append the partDiv to the form
    form.append(partDiv);
});

// Create a submit button
const submitButton = $('<input>', { type: 'submit', value: 'Create Order' });

// Append the submit button to the form
form.append(submitButton);

// Append the form to the document body
$('body').append(form);

// Add event handling for "Keep," "Increase," and "Decrease" buttons
$('.createOrder').on('change', 'input[name="Keep"]', function() {
    // Disable or enable the associated "Increase" and "Decrease" buttons based on "Keep" checkbox
    const increaseButton = $(this).parent().find('button:contains("Increase")');
    const decreaseButton = $(this).parent().find('button:contains("Decrease")');
    if ($(this).is(':checked')) {
        increaseButton.prop('disabled', true);
        decreaseButton.prop('disabled', true);
    } else {
        increaseButton.prop('disabled', false);
        decreaseButton.prop('disabled', false);
    }
});

$('.createOrder').on('click', 'button:contains("Increase"), button:contains("Decrease")', function() {
    // When "Increase" or "Decrease" button is clicked, populate the "action" hidden field and call the calculateOrder function
    const hiddenActionField = $(this).parent().find('input[name="action"]');
    hiddenActionField.val($(this).text());
    calculateOrder();
});

// Function to create constraints and extract data based on selected SKUs
function calculateOrder() {
    const selectedSKUs = [];
    const allParts = packingData.parts;
    
    // Get selected SKUs
    $('input[name="SKU"]').each(function() {
        if ($(this).parent().find('input[name="Keep"]').is(':checked')) {
            selectedSKUs.push($(this).val());
        }
    });

    // Create constraints
    const existingConstraints = {};
    createConstraints(selectedSKUs, allParts, existingConstraints);

    // Extract data
    const selectedData = extractData(selectedSKUs, allParts);

    // Here you can perform further calculations or actions based on selected data
    // For now, let's log the results to the console
    console.log('Selected SKUs:', selectedSKUs);
    console.log('Constraints:', existingConstraints);
    console.log('Selected Data:', selectedData);
}



