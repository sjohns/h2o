
const data = {
  date: '2023-10-18',
  lcm: 60,
  parts: [
    { SKU: 'SKU1', 'Bundle Size': 20, 'Bundles Per Truckload': 3, 'Value To Be Used For Optimization': 10 },
    { SKU: 'SKU2', 'Bundle Size': 50, 'Bundles Per Truckload': 2, 'Value To Be Used For Optimization': 10 },
  ],
};
console.log(data);

const initialSelection = [
  { SKU: 'SKU1', numberOfBundles: 3 },
  { SKU: 'SKU2', numberOfBundles: 0 },
];

// Match SKUs in initialSelection with data.parts and add the missing properties
initialSelection.forEach(selection => {
  const matchingPart = data.parts.find(part => part.SKU === selection.SKU);
  if (matchingPart) {
    selection['bundlesPerTruckload'] = matchingPart['Bundles Per Truckload'];
    selection['bundleSize'] = matchingPart['Bundle Size'];
    selection['orderValue'] = matchingPart['Value To Be Used For Optimization'];
  }
});
console.log(initialSelection);

// Define the constraints
const constraints = [
  // Constraint: numberOfBundles per SKU cannot be less than 0
  part => part.numberOfBundles >= 0,
  // Constraint: numberOfBundles per SKU cannot exceed 'Bundles Per Truckload'
  part => part.numberOfBundles <= part['bundlesPerTruckload'],
  // Constraint: The sum of ("Bundle Size" * 'numberOfBundles') must be equal to data.lcm
  () => data.parts.reduce((sum, part) => sum + part['bundleSize'] * part.numberOfBundles, 0) === data.lcm,
];

// Function to calculate the closeness score
function calculateClosenessScore(parts, initialSelection) {
  let closenessScore = 0;
  parts.forEach(part => {
    const initial = initialSelection.find(sel => sel.SKU === part.SKU);
    if (initial) {
      closenessScore += Math.abs(part.numberOfBundles - initial.numberOfBundles);
    }
  });
  return closenessScore;
}

const initialSatisfiesConstraints = constraints.every(constraint => constraint(initialSelection));

if (initialSatisfiesConstraints) {
  // If the initial selection satisfies constraints, calculate and display the closeness score
  const closenessScore = calculateClosenessScore(data.parts, initialSelection);
  alert('Closeness Score: ' + closenessScore);
}



