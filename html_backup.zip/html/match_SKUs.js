 //           console.log('Data:', data);
            /*
const packingData = {
    "date": "2023-10-29_17-52-03",
    "lcm": 720,
    "parts": [
        {
            "SKU": "1CESF40013SH",
            "partDescription": "1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 360,
            "bundlesPerTruckload": 36,
            "bundleSize": 20,
            "rank": 5
        },
        {
            "SKU": "1CESF40019SH",
            "partDescription": "3/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 400,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 10
        },
        {
            "SKU": "1CESF40025SH",
            "partDescription": "1\" PVC PIPE SCH 40",
            "sticksPerBundle": 280,
            "bundlesPerTruckload": 20,
            "bundleSize": 36,
            "rank": 10
        },
        {
            "SKU": "1 1/4\" PVC PIPE SCH 40",
            "partDescription": "1 1/4\" PVC PIPE SCH 40",
            "sticksPerBundle": 220,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 10
        },
        {
            "SKU": "1CESF40038SH",
            "partDescription": "1 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 180,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 2
        },
        {
            "SKU": "1CESF40050SH",
            "partDescription": "2\" PVC PIPE SCH 40",
            "sticksPerBundle": 105,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 1
        },
        {
            "SKU": "1CESF40060SH",
            "partDescription": "2 1/2\" PVC PIPE SCH 40",
            "sticksPerBundle": 73,
            "bundlesPerTruckload": 24,
            "bundleSize": 30,
            "rank": 3
        },
        {
            "SKU": "1CESF40075SH",
            "partDescription": "3\" PVC PIPE SCH 40",
            "sticksPerBundle": 75,
            "bundlesPerTruckload": 16,
            "bundleSize": 45,
            "rank": 4
        },
        {
            "SKU": "1CESF40100SH",
            "partDescription": "4\" PVC PIPE SCH 40",
            "sticksPerBundle": 57,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 6
        },
        {
            "SKU": "6\" PVC PIPE SCH 40",
            "partDescription": "6\" PVC PIPE SCH 40",
            "sticksPerBundle": 26,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 7
        },
        {
            "SKU": "8\" PVC PIPE SCH 40",
            "partDescription": "8\" PVC PIPE SCH 40",
            "sticksPerBundle": 15,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 8
        },
        {
            "SKU": "10\" PVC PIPE SCH 40",
            "partDescription": "10\" PVC PIPE SCH 40",
            "sticksPerBundle": 12,
            "bundlesPerTruckload": 12,
            "bundleSize": 60,
            "rank": 10
        }
    ]
};

console.log('packingData = ',packingData);

const selectedSKUs = [
  "1CESF40013SH",
  "1CESF40019SH",
  "1CESF40025SH"
];
console.log('selectedSKUs = ', selectedSKUs);
*/



//const numberSelectedSKUs = selectedSKUs.length;


/*
const SKUs = data
  .slice() // Create a copy of data to avoid modifying the original array
  .sort((a, b) => b.rank - a.rank) // Sort by bundleSize in descending order
  .map(data => data.SKU); // Map to an array of SKUs
console.log('SKUs = ',SKUs);

let bundleConstraints = {}; // Define bundleConstraints here
data.forEach(data => {
  bundleConstraints[data.SKU] = {
    minNumberOfBundles: 1,
    maxNumberOfBundles: data.bundlesPerTruckload
  };
});
console.log("bundleConstraints:", bundleConstraints);

const minTruckSize = data.every(data => data.bundleSize % modSize === 0) ? maxTruckSize : truckFraction * maxTruckSize;

let truckSizeConstraint = {
  minTruckSize: minTruckSize,
  maxTruckSize: maxTruckSize
};
console.log("truckSizeConstraint:", truckSizeConstraint);

function calculateBundleDifference(solution) {
  const sumOfSquares = solution.reduce((sum, item) => {
    return sum + Math.pow(item.numberOfBundles, 2);
  }, 0);
  const average = sumOfSquares / solution.length;
  return average;
}

function findAllSolutions(truckSizeConstraint, bundleConstraints) {
  function findCombinations(skus, solution, totalSize) {
    if (skus.length === 0) {
      if (totalSize >= truckSizeConstraint.minTruckSize && totalSize <= truckSizeConstraint.maxTruckSize) {
        solutions.push([...solution]);
      }
      return;
    }

    const sku = skus[0];
    const constraints = bundleConstraints[sku];
    for (let bundles = Math.max(constraints.minNumberOfBundles, 1); bundles <= constraints.maxNumberOfBundles; bundles++) {
      solution.push({ SKU: sku, numberOfBundles: bundles });
      findCombinations(skus.slice(1), solution, totalSize + bundles * packingData.parts.find(part => part.SKU === sku).bundleSize);
      solution.pop();
    }
  }

  const solutions = [];
  const allSKUs = Object.keys(bundleConstraints);
  findCombinations(allSKUs, [], 0);
  return solutions;
};
function findSolutionWithMinDifference(allPossibleSolutions) {
  let minDifference = Infinity;
  let bestSolution = null;

  for (const solution of allPossibleSolutions) {
    const difference = calculateBundleDifference(solution);
    if (difference < minDifference) {
      minDifference = difference;
      bestSolution = solution;
    }
  }

  return { bestSolution, minDifference };
}


const allPossibleSolutions = findAllSolutions(truckSizeConstraint, bundleConstraints);
console.log("All Possible Solutions:", allPossibleSolutions);

const { bestSolution, minDifference } = findSolutionWithMinDifference(allPossibleSolutions);
console.log("Best Solution:", bestSolution);
console.log("Minimum Difference:", minDifference);
*/


