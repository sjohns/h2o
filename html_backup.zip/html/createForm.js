// JavaScript code to create the form and add rows for each SKU
function createPackingDataForm(SKUs) {
    const packingDataForm = document.createElement('form');
    packingDataForm.id = 'select_SKUs';
    packingDataForm.method = 'POST';  // Use POST method for form submission

    const table = document.createElement('table');
    table.border = '1';

    const tableHeader = document.createElement('tr');
    const headers = ['Part Description', 'Select'];

    headers.forEach(headerText => {
        const header = document.createElement('th');
        header.textContent = headerText;
        tableHeader.appendChild(header);
    });

    table.appendChild(tableHeader);

    SKUs.forEach(sku => {
        const row = document.createElement('tr');

        // Part Description
        const partDescriptionCell = document.createElement('td');
        partDescriptionCell.textContent = sku.partDescription;
        row.appendChild(partDescriptionCell);

        // Create a checkbox cell
        const selectCell = document.createElement('td');
        const selectCheckbox = document.createElement('input');
        selectCheckbox.type = 'checkbox';
        selectCheckbox.name = 'selectedSKUs';
        selectCheckbox.value = sku.SKU; // Use SKU as the checkbox value
        selectCell.appendChild(selectCheckbox);
        row.appendChild(selectCell);

        table.appendChild(row);
    });

    packingDataForm.appendChild(table);

    // Add a hidden input field to store selected SKUs
    const selectedSKUsInput = document.createElement('input');
    selectedSKUsInput.type = 'hidden';
    selectedSKUsInput.name = 'selectedSKUs';
    packingDataForm.appendChild(selectedSKUsInput);

    // Add a submit button to submit the form
    const submitButton = document.createElement('input');
    submitButton.type = 'submit';
    submitButton.value = 'Submit';
    packingDataForm.appendChild(submitButton);

    // Add an event listener to the form to handle form submission
    packingDataForm.addEventListener('submit', function (e) {
        e.preventDefault(); // Prevent the default form submission

        // Retrieve selected SKUs here
        const selectedSKUs = Array.from(packingDataForm.querySelectorAll('input[name=selectedSKUs]:checked')).map(checkbox => checkbox.value);

        // Set the value of the hidden input field
        selectedSKUsInput.value = selectedSKUs.join(',');  // Set the selected SKUs as a comma-separated string

        // Check if at least one SKU is selected
        if (selectedSKUs.length === 0) {
            alert('Please select at least one SKU before submitting.');
        } else {
            console.log('Selected SKUs:', selectedSKUs);
            // Redirect to the new page with the selected SKUs in the URL
            window.location.href = 'index_2.html?selectedSKUs=' + selectedSKUs.join(',');

            // Reset the form after submission
//            packingDataForm.reset();
        }
    });

    document.body.appendChild(packingDataForm);
}

document.addEventListener('DOMContentLoaded', function() {
    // Call the function to create the form and add rows for each SKU, passing the allSKUs array
    createPackingDataForm(packingData.parts);
});
